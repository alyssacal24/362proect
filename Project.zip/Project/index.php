<?php
session_start();
// Optional: Include DB connection if you want to dynamically list quizzes later
// include('db_connection.php');
?>

<!DOCTYPE html>
<html>
<head>
    <title>Personality Quiz Home</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>Welcome to the Personality Quiz Site</h1>
        <div class="auth-links">
            <?php if (isset($_SESSION['user_id']) && isset($_SESSION['username'])): ?>
                <p class="user-info">Logged in as <strong><?php echo htmlspecialchars($_SESSION['username']); ?></strong></p>
                <a href="login/logout.php" class="button">Logout</a>
                 <?php if (isset($_SESSION['is_admin']) && $_SESSION['is_admin'] === true): ?>
                    | <a href="admin/dashboard.php" class="button">Admin Panel</a> <!-- Optional Admin Link -->
                 <?php endif; ?>
            <?php else: ?>
                <a href="login/register.php" class="button">Register</a>
                <a href="login/login.php" class="button">Login</a>
            <?php endif; ?>
        </div>

        <div class="quiz-list">
            <h2>Available Quizzes</h2>

            <!-- NOTE: Ideally, this section should be generated dynamically -->
            <!-- by fetching active quizzes from the database -->

            <!-- Quiz Item 1 -->
            <div class="quiz-item">
                <img src="images/livingroom.png" alt="Living Room Quiz Thumbnail">
                <a href="quizzes/take_quiz.php?id=1">Living Room Personality Quiz</a>
            </div>

            <!-- Quiz Item 2 -->
            <div class="quiz-item">
                <img src="images/seasons.jpg" alt="Season Quiz Thumbnail">
                <a href="quizzes/take_quiz.php?id=2">What Season Are You?</a>
            </div>

            <!-- Quiz Item 3 -->
            <div class="quiz-item">
                <img src="images/characters.webp" alt="Cartoon Character Quiz Thumbnail">
                <a href="quizzes/take_quiz.php?id=3">Which Cartoon Character Are You?</a>
            </div>

            <!-- Quiz Item 4 -->
            <div class="quiz-item">
                <img src="images/juices.avif" alt="Juice Box Quiz Thumbnail">
                <a href="quizzes/take_quiz.php?id=4">Which Juice Are You?</a>
            </div>
            <!-- End Quiz Item 4 -->

            <!-- Quiz Item 5 -->
            <div class="quiz-item">
                <img src="images/spongebob4.jpg" alt="SpongeBob Character Quiz Thumbnail">
                <a href="quizzes/take_quiz.php?id=5">Which SpongeBob Character Are You?</a>
            </div>
            <!-- End Quiz Item 5 -->

            <!-- Quiz Item 6 -->
            <div class="quiz-item">
                <img src="images/enemy.avif" alt="Enemy Quiz Thumbnail">
                <a href="quizzes/take_quiz.php?id=6">Who Is Your Enemy?</a>
            </div>
            <!-- End Quiz Item 6 -->

            <!-- Quiz Item 7 -->
            <div class="quiz-item">
                <img src="images/icecream.jpg" alt="Ice Cream Quiz Thumbnail">
                <a href="quizzes/take_quiz.php?id=7">Which Ice Cream Are You?</a>
            </div>
            <!-- End Quiz Item 7 -->

            <!-- Quiz Item 8 -->
            <div class="quiz-item">
                <img src="images/candy.jpg" alt="Candy Quiz Thumbnail">
                <a href="quizzes/take_quiz.php?id=8">What Candy Are You?</a>
            </div>
            <!-- End Quiz Item 8 -->

            <!-- !!! ADDED QUIZ ITEM 9 !!! -->
            <div class="quiz-item">
                <!-- Choose an appropriate thumbnail image -->
                <img src="images/spaghetti.jpg" alt="Pasta Quiz Thumbnail"> <!-- Example thumbnail -->
                 <!-- Link to take_quiz.php with the correct ID -->
                <a href="quizzes/take_quiz.php?id=9">Which Pasta Are You?</a>
            </div>
            <!-- End Quiz Item 9 -->

            <!-- Add more quizzes here if needed, linking with their correct IDs -->

        </div> <!-- end .quiz-list -->
    </div> <!-- end .container -->
</body>
</html>
