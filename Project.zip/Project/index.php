<?php
session_start();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Personality Quiz Home</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>Welcome to the Personality Quiz Site</h1>
        <div class="auth-links">
            <?php if (isset($_SESSION['user_id']) && isset($_SESSION['username'])): ?>
                <p class="user-info">Logged in as <strong><?php echo htmlspecialchars($_SESSION['username']); ?></strong></p>
                <a href="login/logout.php" class="button">Logout</a>
            <?php else: ?>
                <a href="login/register.php" class="button">Register</a>
                <a href="login/login.php" class="button">Login</a>
            <?php endif; ?>
        </div>

        <div class="quiz-list">
            <h2>Available Quizzes</h2>

            <!-- Quiz Item 1 -->
            <div class="quiz-item">
                <img src="images/livingroom.png" alt="Living Room Quiz Thumbnail">
                <a href="quizzes/quiz.php">Living Room Personality Quiz</a>
            </div>

            <!-- Quiz Item 2 -->
            <div class="quiz-item">
                <img src="images/seasons.jpg" alt="Season Quiz Thumbnail">
                <a href="quizzes/quiz2.php">What Season Are You?</a>
            </div>

            <!-- Quiz Item 3 -->
            <div class="quiz-item">
                <img src="images/characters.webp" alt="Cartoon Character Quiz Thumbnail">
                <a href="quizzes/quiz3.php">Which Cartoon Character Are You?</a>
            </div>

            <!-- Quiz Item 4 - ADDED -->
            <div class="quiz-item">
                <img src="images/juices.avif" alt="Juice Box Quiz Thumbnail"> <!-- Use your thumbnail -->
                <a href="quizzes/quiz4.php">What Juice Box Are You Spiritually?</a>
            </div>
            <!-- End Quiz Item 4 -->

        </div> <!-- end .quiz-list -->
    </div> <!-- end .container -->
</body>
</html>
