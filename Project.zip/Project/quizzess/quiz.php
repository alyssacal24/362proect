<?php
session_start();
include '../db_connection.php';

$result = "";
$imagePath = ""; // Initialize image path variable
$primaryCategory = ""; // Initialize primary category
$answeredAll = true; // Flag to check if all questions were answered

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // --- PHP code for processing the form ---
    // Quiz 1 specific scores
    $scores = [
        "Modern" => 0,
        "Spongebob" => 0,
        "Conversation Pit" => 0,
        "Minimalist" => 0
    ];

    $questions = ['q1', 'q2', 'q3', 'q4'];

    // Check if all questions have been submitted
    foreach ($questions as $q) {
        if (!isset($_POST[$q])) {
            $answeredAll = false;
            break;
        }
    }

    // Proceed only if all questions were answered
    if ($answeredAll) {
        foreach ($questions as $q) {
            // We already know $_POST[$q] is set from the check above
            $choice = $_POST[$q];
            if (array_key_exists($choice, $scores)) {
                $scores[$choice]++;
            }
        }

        $maxScore = max($scores);
        $topCategories = array_keys($scores, $maxScore);

        // Quiz 1 specific descriptions
        $descriptions = [
            "Modern" => "You are a Modern Living Room!",
            "Spongebob" => "You are a Spongebob Living Room!",
            "Conversation Pit" => "You are a Conversation Pit Living Room",
            "Minimalist" => "You are a Minimalist Living Room!"
        ];

        if (count($topCategories) > 1) {
            $result = "You have traits from multiple types: " . implode(", ", $topCategories);
            $primaryCategory = $topCategories[0]; // Pick the first category for the image in case of a tie
        } else {
            $primaryCategory = $topCategories[0];
            $result = $descriptions[$primaryCategory];
        }

        // --- Construct Image Path using explicit map ---
        if (!empty($primaryCategory)) {
             // Quiz 1 specific image map
             $imageMap = [
                 "Modern"           => 'modern.webp',
                 "Spongebob"        => 'SpongebobLivingRoom.png', // Living room image
                 "Conversation Pit" => 'conversationpit.jpg',
                 "Minimalist"       => 'minimalist.webp'
             ];
             $imageName = $imageMap[$primaryCategory] ?? ''; // Find image name in map

             if (!empty($imageName)) {
                 $potentialImagePath = '../images/' . $imageName;
                 $serverPath = $_SERVER['DOCUMENT_ROOT'] . '/Project/images/' . $imageName;
                 if (file_exists($serverPath)) {
                     $imagePath = $potentialImagePath; // Set web path if file exists
                 } else {
                     $imagePath = ""; // Clear path if file missing
                     error_log("Missing image file for quiz.php: " . $serverPath);
                 }
             } else {
                  $imagePath = ""; // Clear path if category not in map
                  error_log("No image mapped for category in quiz.php: " . $primaryCategory);
             }
         }
        // --- End Image Path Construction ---


        // Save answer if user is logged in
        if (isset($_SESSION['user_id'])) {
            $user_id = $_SESSION['user_id'];
            $quiz_id = 1; // Quiz ID for this quiz (Living Room)
            if (!empty($result)) {
                 $stmt = $conn->prepare("INSERT INTO quiz_answers (user_id, quiz_id, result) VALUES (?, ?, ?)");
                 if ($stmt) { // Check prepare success
                     $stmt->bind_param("iis", $user_id, $quiz_id, $result);
                     $stmt->execute();
                     $stmt->close();
                 } else {
                     error_log("Failed to prepare statement for quiz.php: " . $conn->error);
                 }
            }
        }
    } else { // Handle case where not all questions were answered
        $result = "Please answer all questions.";
    }
    // --- End of PHP processing ---
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Living Room Personality Quiz</title> <!-- Quiz 1 Title -->
    <!-- Styling (same as quiz2.php & quiz3.php) -->
    <style>
        body { font-family: sans-serif; line-height: 1.6; padding: 20px; }
        h2, h3 { text-align: center; }
        form { max-width: 600px; margin: 20px auto; padding: 20px; border: 1px solid #ccc; border-radius: 8px; }
        form p { font-weight: bold; }
        label { display: block; margin-bottom: 8px; cursor: pointer; }
        button { display: block; margin: 20px auto; padding: 10px 25px; font-size: 16px; cursor: pointer; }
        .result-container { text-align: center; margin-top: 30px; }
        .result-container img { border: 1px solid #eee; padding: 5px; margin-top: 15px; max-width: 90%; height: auto; max-height: 300px; /* Optional max height */ }
        .nav-links { text-align: center; margin-top: 20px; }
        .nav-links a { margin: 0 10px; }
        .login-info { text-align: right; font-size: 0.9em; color: #555; }
    </style>
</head>
<body>

<div class="login-info">
<?php if (isset($_SESSION['user_id'])): ?>
    <p>Welcome back!</p>
<?php else: ?>
    <p>You're taking the quiz as a guest. <a href="../login/login.php">Log in</a> to save your results.</p>
<?php endif; ?>
</div>

<h2>Living Room Personality Quiz</h2> <!-- Quiz 1 Heading -->

<!-- Result Display Section (matches quiz2/quiz3 structure) -->
<?php if ($_SERVER['REQUEST_METHOD'] == 'POST' && !empty($result) && $answeredAll): ?>
    <div class="result-container">
        <h3>Your Result:</h3>
        <p><?php echo htmlspecialchars($result); ?></p>

        <!-- Display the image if a valid path was found -->
        <?php if (!empty($imagePath)): ?>
            <img src="<?php echo htmlspecialchars($imagePath); ?>" alt="<?php echo htmlspecialchars($primaryCategory); ?> Result">
            <br>
        <?php elseif(!empty($primaryCategory)): ?>
             <!-- Optional: Show message if image file was missing or not mapped -->
             <p><small>(Image for <?php echo htmlspecialchars($primaryCategory); ?> not found)</small></p>
        <?php endif; ?>
        <!-- End image -->
    </div>
    <div class="nav-links">
        <a href="quiz.php">Take it again</a> <!-- Link to self -->
        <a href="../index.php">Go back to the main menu</a>
    </div>
<?php elseif ($_SERVER['REQUEST_METHOD'] == 'POST' && !$answeredAll): ?> <!-- Handle incomplete submission -->
     <div class="result-container">
        <p style="color: red;"><?php echo htmlspecialchars($result); ?></p> <!-- Show error -->
        <a href="quiz.php">Try again</a> <!-- Link to self -->
     </div>
<?php else: ?>
    <!-- The form for Quiz 1 -->
    <form method="POST" action="quiz.php" id="quiz-form"> <!-- Action points to self -->
        <p>1. What is your dream job?</p>
        <label><input type="radio" name="q1" value="Modern" required> Influencer</label><br>
        <label><input type="radio" name="q1" value="Spongebob"> Flipping Burgers</label><br>
        <label><input type="radio" name="q1" value="Conversation Pit"> Milkman</label><br>
        <label><input type="radio" name="q1" value="Minimalist"> Receptionist</label><br>

        <p>2. What is your go to outfit?</p>
        <label><input type="radio" name="q2" value="Modern" required> Baggy Jeans</label><br>
        <label><input type="radio" name="q2" value="Spongebob"> Short Sleeve Shirt</label><br>
        <label><input type="radio" name="q2" value="Conversation Pit"> Bell Bottoms</label><br>
        <label><input type="radio" name="q2" value="Minimalist"> Plain White Tee</label><br>

        <p>3. Dream House?</p>
        <label><input type="radio" name="q3" value="Modern" required> White and Square</label><br>
        <label><input type="radio" name="q3" value="Spongebob"> A Pineapple</label><br>
        <label><input type="radio" name="q3" value="Conversation Pit"> Retro</label><br>
        <label><input type="radio" name="q3" value="Minimalist"> Brown Siding</label><br>

        <p>4. Favorite movie?</p>
        <label><input type="radio" name="q4" value="Modern" required> Everything Everywhere All At Once</label><br>
        <label><input type="radio" name="q4" value="Spongebob"> SpongeBob Movie</label><br>
        <label><input type="radio" name="q4" value="Conversation Pit"> The Godfather</label><br>
        <label><input type="radio" name="q4" value="Minimalist"> Forrest Gump</label><br>

        <button type="submit">Submit</button>
    </form>
<?php endif; ?>
<!-- End Result Display Section -->

<script src="quiz.js"></script> <!-- Link to correct JS file -->

</body>
</html>
