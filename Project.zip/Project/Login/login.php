<?php
session_start();
// Ensure the path is correct relative to the Login folder
include('../db_connection.php');

$error = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username']);
    $password = $_POST['password'];

    // --- CHANGE 1: Select the 'role' column ---
    $stmt = $conn->prepare("SELECT id, username, password, role FROM users WHERE username = ?");
    if (!$stmt) {
        // Handle prepare error (e.g., log it, show generic error)
        die("Database prepare error: " . $conn->error);
    }

    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
    $stmt->close(); // Close statement after fetching

    if ($user && password_verify($password, $user['password'])) {
        // --- CHANGE 2: Store user ID, username, role, and admin status in session ---
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['user_role'] = $user['role']; // Store the actual role ('admin' or 'user')
        $_SESSION['is_admin'] = ($user['role'] === 'admin'); // Set true if role is 'admin', false otherwise

        // --- CHANGE 3 (Optional but Recommended): Redirect based on role ---
        if ($_SESSION['is_admin']) {
            header('Location: ../admin/dashboard.php'); // Redirect admins to admin dashboard
        } else {
            header('Location: ../index.php'); // Redirect regular users to main page
        }
        exit(); // Important: exit after header redirect

    } else {
        $error = "Invalid username or password!"; // More specific error message
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <link rel="stylesheet" href="../style.css"> <!-- Link your CSS -->
     <style>
        /* Basic form styling */
        body { font-family: sans-serif; padding: 20px; }
        h2 { text-align: center; }
        form { max-width: 300px; margin: 20px auto; padding: 20px; border: 1px solid #ccc; border-radius: 5px; }
        form input { width: 90%; padding: 8px; margin-bottom: 10px; }
        form button { padding: 10px 15px; cursor: pointer; }
        p { text-align: center; }
        .error { color: red; text-align: center; font-weight: bold; margin-bottom: 15px;}
    </style>
</head>
<body>

<h2>Login</h2>

<?php if ($error): ?>
    <p class="error"><?php echo htmlspecialchars($error); ?></p>
<?php endif; ?>

<form method="post" action="login.php"> <!-- Good practice to specify action -->
    Username: <input type="text" name="username" required><br>
    Password: <input type="password" name="password" required><br>
    <button type="submit">Login</button>
</form>

<p>Don't have an account? <a href="register.php">Register here</a></p>
<p><a href="../index.php">Back to Home</a></p>

</body>
</html>
<?php
if (isset($conn)) { // Close connection if it was opened
    $conn->close();
}
?>
