<?php
// File: admin/delete_question.php

require_once __DIR__ . '/auth_check.php'; // Auth check and $conn

// Check if the request method is POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: manage_quizzes.php'); // Redirect if not POST
    exit;
}

// Get and Validate Question ID from POST data
if (!isset($_POST['id']) || !filter_var($_POST['id'], FILTER_VALIDATE_INT)) {
    header('Location: manage_quizzes.php?error=invalid_q_id'); // Redirect if ID invalid
    exit;
}
$question_id = (int)$_POST['id'];

// Get and Validate Quiz ID from POST data (for redirection)
if (!isset($_POST['quiz_id']) || !filter_var($_POST['quiz_id'], FILTER_VALIDATE_INT)) {
    // If quiz_id is missing, we can't redirect properly, go back to main list
    header('Location: manage_quizzes.php?error=missing_quiz_id_for_redirect');
    exit;
}
$quiz_id = (int)$_POST['quiz_id'];


// Prepare the DELETE statement
// Assumes ON DELETE CASCADE is set for the options table foreign key referencing questions.id
$stmt = $conn->prepare("DELETE FROM questions WHERE id = ?");

if ($stmt) {
    $stmt->bind_param("i", $question_id);

    // Execute the statement
    if ($stmt->execute()) {
        // Check if any row was actually deleted
        if ($stmt->affected_rows > 0) {
            // Success! Redirect back to the questions list
            header('Location: manage_questions.php?quiz_id=' . $quiz_id . '&status=q_deleted');
            exit;
        } else {
            // Question ID might not have existed
            header('Location: manage_questions.php?quiz_id=' . $quiz_id . '&error=q_not_found');
            exit;
        }
    } else {
        // Execution failed (e.g., foreign key constraint if CASCADE not set on options)
        error_log("Execute failed for DELETE question: " . $stmt->error);
        header('Location: manage_questions.php?quiz_id=' . $quiz_id . '&error=q_delete_failed');
        exit;
    }
    $stmt->close();
} else {
    // Prepare failed
    error_log("Prepare failed for DELETE question: " . $conn->error);
    header('Location: manage_questions.php?quiz_id=' . $quiz_id . '&error=db_error');
    exit;
}

$conn->close();

?>
