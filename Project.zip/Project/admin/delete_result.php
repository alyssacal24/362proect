<?php
// File: admin/delete_result.php

require_once __DIR__ . '/auth_check.php'; // Auth check and $conn

// Check if the request method is POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: manage_quizzes.php'); // Redirect if not POST
    exit;
}

// Get and Validate Result Definition ID from POST data
if (!isset($_POST['id']) || !filter_var($_POST['id'], FILTER_VALIDATE_INT)) {
    header('Location: manage_quizzes.php?error=invalid_res_id'); // Redirect if ID invalid
    exit;
}
$result_id = (int)$_POST['id'];

// Get and Validate Quiz ID from POST data (for redirection)
if (!isset($_POST['quiz_id']) || !filter_var($_POST['quiz_id'], FILTER_VALIDATE_INT)) {
    // If quiz_id is missing, we can't redirect properly
    header('Location: manage_quizzes.php?error=missing_quiz_id_for_redirect');
    exit;
}
$quiz_id = (int)$_POST['quiz_id'];

// --- Optional: Check if any options are still using this category_name before deleting ---
// $stmt_check = $conn->prepare("SELECT o.id FROM options o JOIN result_definitions rd ON o.personality_type = rd.category_name WHERE rd.id = ? AND rd.quiz_id = ? LIMIT 1");
// if ($stmt_check) {
//     $stmt_check->bind_param("ii", $result_id, $quiz_id);
//     $stmt_check->execute();
//     if ($stmt_check->get_result()->num_rows > 0) {
//         // Options still use this result category! Prevent deletion or warn user more strongly.
//         header('Location: manage_results.php?quiz_id=' . $quiz_id . '&error=res_in_use');
//         exit;
//     }
//     $stmt_check->close();
// } // else: Handle prepare error if needed


// Prepare the DELETE statement
$stmt = $conn->prepare("DELETE FROM result_definitions WHERE id = ?");

if ($stmt) {
    $stmt->bind_param("i", $result_id);

    // Execute the statement
    if ($stmt->execute()) {
        // Check if any row was actually deleted
        if ($stmt->affected_rows > 0) {
            // Success! Redirect back to the results list
            header('Location: manage_results.php?quiz_id=' . $quiz_id . '&status=res_deleted');
            exit;
        } else {
            // Result ID might not have existed
            header('Location: manage_results.php?quiz_id=' . $quiz_id . '&error=res_not_found');
            exit;
        }
    } else {
        // Execution failed
        error_log("Execute failed for DELETE result definition: " . $stmt->error);
        header('Location: manage_results.php?quiz_id=' . $quiz_id . '&error=res_delete_failed');
        exit;
    }
    $stmt->close();
} else {
    // Prepare failed
    error_log("Prepare failed for DELETE result definition: " . $conn->error);
    header('Location: manage_results.php?quiz_id=' . $quiz_id . '&error=db_error');
    exit;
}

$conn->close();

?>
