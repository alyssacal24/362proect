<?php
// File: admin/edit_result.php

// --- ENABLE ERROR REPORTING (Add this temporarily for debugging) ---
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
// ---------------------------------------------

require_once __DIR__ . '/auth_check.php'; // Auth check and $conn

// --- Get Quiz ID (Required) ---
// Get from GET on initial load, or POST on submission
if (isset($_REQUEST['quiz_id']) && filter_var($_REQUEST['quiz_id'], FILTER_VALIDATE_INT)) {
    $quiz_id = (int)$_REQUEST['quiz_id'];
} else {
    header('Location: manage_quizzes.php?error=missing_quiz_id');
    exit;
}

// --- Fetch Quiz Name (for context) ---
$quiz_name = '';
$stmt_quiz = $conn->prepare("SELECT name FROM quizzes WHERE id = ?");
if ($stmt_quiz) {
    $stmt_quiz->bind_param("i", $quiz_id);
    $stmt_quiz->execute();
    $result_quiz = $stmt_quiz->get_result();
    if ($quiz = $result_quiz->fetch_assoc()) {
        $quiz_name = $quiz['name'];
    } else {
        // Quiz not found for this result definition? Should not happen if linked correctly.
        header('Location: manage_quizzes.php?error=quiz_not_found_for_result');
        exit;
    }
    $stmt_quiz->close();
} else {
    error_log("Prepare failed for SELECT quiz name in edit_result: " . $conn->error);
    // Decide how to handle - show error or redirect
    die("Database error fetching quiz name."); // Simple error for debugging
}


// --- Initialize variables ---
$result_id = null;
$category_name = '';
$result_description = '';
$image_filename = ''; // Optional image
$form_mode = 'Add';
$error_message = '';

// --- Check if editing an existing result definition ---
if (isset($_GET['id']) && filter_var($_GET['id'], FILTER_VALIDATE_INT)) {
    $result_id = (int)$_GET['id'];
    $form_mode = 'Edit';

    // Fetch existing result data
    $stmt = $conn->prepare("SELECT category_name, result_description, image_filename FROM result_definitions WHERE id = ? AND quiz_id = ?");
    if ($stmt) {
        $stmt->bind_param("ii", $result_id, $quiz_id);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($r_data = $result->fetch_assoc()) {
            $category_name = $r_data['category_name'];
            $result_description = $r_data['result_description'];
            $image_filename = $r_data['image_filename'] ?? ''; // Handle null image
        } else {
            error_log("Admin tried to edit non-existent result ID: " . $result_id . " for quiz " . $quiz_id);
            header('Location: manage_results.php?quiz_id=' . $quiz_id . '&error=res_not_found');
            exit;
        }
        $stmt->close();
    } else {
        error_log("Prepare failed for SELECT result definition: " . $conn->error);
        $error_message = "Database error fetching result details.";
        $form_mode = 'Error'; // Prevent form display/submission
    }
}

// --- Handle Form Submission (POST request) ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $form_mode !== 'Error') {
    // Get data from POST
    // quiz_id is already known from $_REQUEST['quiz_id'] above
    $submitted_id = isset($_POST['id']) ? (int)$_POST['id'] : null;
    $submitted_category = trim($_POST['category_name'] ?? '');
    $submitted_description = trim($_POST['result_description'] ?? '');
    $submitted_image = trim($_POST['image_filename'] ?? ''); // Handle optional image filename

    // Basic Validation
    if (empty($submitted_category)) {
        $error_message = "Category Name cannot be empty.";
    } elseif (empty($submitted_description)) {
         $error_message = "Result Description cannot be empty.";
    }
    // Add more validation if needed (e.g., category name uniqueness within the quiz)

    else {
        // Decide whether to INSERT or UPDATE
        if ($submitted_id !== null && $submitted_id > 0) {
            // --- UPDATE existing result ---
            $stmt = $conn->prepare("UPDATE result_definitions SET category_name = ?, result_description = ?, image_filename = ? WHERE id = ? AND quiz_id = ?");
             // Use null for image if empty string submitted
            $image_to_save = !empty($submitted_image) ? $submitted_image : null;
            if ($stmt) {
                // Note: type 's' for image_filename even if null, bind_param handles it
                $stmt->bind_param("sssii", $submitted_category, $submitted_description, $image_to_save, $submitted_id, $quiz_id);
                if ($stmt->execute()) {
                    header('Location: manage_results.php?quiz_id=' . $quiz_id . '&status=res_updated');
                    exit;
                } else {
                    error_log("Execute failed for UPDATE result definition: " . $stmt->error);
                    $error_message = "Failed to update result definition. Database error.";
                }
                $stmt->close();
            } else {
                error_log("Prepare failed for UPDATE result definition: " . $conn->error);
                $error_message = "Failed to update result definition. Database prepare error.";
            }
            // Keep submitted values on error
            $result_id = $submitted_id;
            $category_name = $submitted_category;
            $result_description = $submitted_description;
            $image_filename = $submitted_image;

        } else {
            // --- INSERT new result ---
            $stmt = $conn->prepare("INSERT INTO result_definitions (quiz_id, category_name, result_description, image_filename) VALUES (?, ?, ?, ?)");
            // Use null for image if empty string submitted
            $image_to_save = !empty($submitted_image) ? $submitted_image : null;
            if ($stmt) {
                 // Note: type 's' for image_filename even if null, bind_param handles it
                $stmt->bind_param("isss", $quiz_id, $submitted_category, $submitted_description, $image_to_save);
                 if ($stmt->execute()) {
                    header('Location: manage_results.php?quiz_id=' . $quiz_id . '&status=res_added');
                    exit;
                } else {
                    error_log("Execute failed for INSERT result definition: " . $stmt->error);
                    // Check for duplicate category name error (depends on DB constraints)
                    if ($conn->errno == 1062) { // MySQL duplicate entry error code
                         $error_message = "Failed to add result definition. The Category Name '$submitted_category' already exists for this quiz.";
                    } else {
                        $error_message = "Failed to add result definition. Database error.";
                    }
                }
                $stmt->close();
            } else {
                 error_log("Prepare failed for INSERT result definition: " . $conn->error);
                 $error_message = "Failed to add result definition. Database prepare error.";
            }
             // Keep submitted values on error
            $category_name = $submitted_category;
            $result_description = $submitted_description;
            $image_filename = $submitted_image;
        }
    }
     // If validation failed, keep submitted values
    if (!empty($error_message)) {
        $result_id = $submitted_id; // Preserve ID if editing
        $category_name = $submitted_category;
        $result_description = $submitted_description;
        $image_filename = $submitted_image;
    }

} // End POST handling

?>
<!DOCTYPE html>
<html>
<head>
    <title>Admin - <?php echo $form_mode; ?> Result Definition</title>
    <link rel="stylesheet" href="../style.css"> <!-- Link to your main CSS -->
    <style>
        /* Re-use or adapt styles from edit_quiz.php/edit_question.php */
        body { padding: 20px; font-family: sans-serif; }
        .form-container { max-width: 600px; margin: 20px auto; padding: 20px; border: 1px solid #ccc; border-radius: 5px; background-color: #f9f9f9; }
        .form-container h1 { text-align: center; margin-bottom: 20px; }
        .form-group { margin-bottom: 15px; }
        .form-group label { display: block; margin-bottom: 5px; font-weight: bold; }
        .form-group input[type="text"],
        .form-group textarea {
            width: 95%; /* Adjust as needed */
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        .form-group textarea { min-height: 100px; }
        .form-actions { text-align: center; margin-top: 20px; }
        .form-actions button { padding: 10px 20px; background-color: #4CAF50; color: white; border: none; border-radius: 4px; cursor: pointer; font-size: 16px; }
        .form-actions button:hover { background-color: #45a049; }
        .error { color: red; text-align: center; margin-bottom: 15px; font-weight: bold; }
        .nav-links { margin-bottom: 20px; }
        .nav-links a { margin-right: 10px; }
        .context { background-color: #eee; padding: 10px; margin-bottom: 15px; border-radius: 4px; }
        .note { font-size: 0.9em; color: #555; margin-top: 5px; display: block;}
    </style>
</head>
<body>

<div class="form-container">
    <div class="nav-links">
        <a href="manage_results.php?quiz_id=<?php echo $quiz_id; ?>">Back to Result Definitions List</a> |
        <a href="dashboard.php">Admin Dashboard</a>
    </div>

    <h1><?php echo $form_mode; ?> Result Definition</h1>
     <div class="context">
        <p><strong>Quiz:</strong> <?php echo htmlspecialchars($quiz_name); ?></p>
    </div>

    <?php if (!empty($error_message)): ?>
        <p class="error"><?php echo htmlspecialchars($error_message); ?></p>
    <?php endif; ?>

    <?php if ($form_mode !== 'Error'): ?>
    <form action="edit_result.php" method="POST">
        <!-- Important: Keep quiz_id in the form -->
        <input type="hidden" name="quiz_id" value="<?php echo $quiz_id; ?>">
        <?php if ($result_id): // Include hidden ID field only when editing ?>
            <input type="hidden" name="id" value="<?php echo $result_id; ?>">
        <?php endif; ?>

        <div class="form-group">
            <label for="category_name">Category Name:</label>
            <input type="text" id="category_name" name="category_name" value="<?php echo htmlspecialchars($category_name); ?>" required>
            <small class="note">This name must exactly match the 'Result Category (Type)' selected for options.</small>
        </div>

        <div class="form-group">
            <label for="result_description">Result Description:</label>
            <textarea id="result_description" name="result_description" required><?php echo htmlspecialchars($result_description); ?></textarea>
             <small class="note">This is the text shown to the user when they get this result.</small>
        </div>

        <div class="form-group">
            <label for="image_filename">Image Filename (Optional):</label>
            <input type="text" id="image_filename" name="image_filename" value="<?php echo htmlspecialchars($image_filename); ?>">
            <small class="note">Example: `result_image.jpg`. Image must be uploaded separately to an accessible folder (e.g., `/Project/images/`). Leave blank for no image.</small>
        </div>


        <div class="form-actions">
            <button type="submit"><?php echo ($form_mode === 'Edit' ? 'Update' : 'Add'); ?> Result Definition</button>
        </div>
    </form>
    <?php endif; // End check for form_mode !== 'Error' ?>

</div>

</body>
</html>
<?php
$conn->close(); // Close the database connection
?>
