<?php
// File: admin/manage_options.php

require_once __DIR__ . '/auth_check.php'; // Auth check and $conn

// --- Get and Validate Question ID ---
if (!isset($_GET['question_id']) || !filter_var($_GET['question_id'], FILTER_VALIDATE_INT)) {
    header('Location: manage_quizzes.php?error=invalid_question_id');
    exit;
}
$question_id = (int)$_GET['question_id'];

// --- Fetch Question Text and Quiz ID ---
$question_text = '';
$quiz_id = null;
$stmt_q = $conn->prepare("SELECT question, quiz_id FROM questions WHERE id = ?");
if ($stmt_q) {
    $stmt_q->bind_param("i", $question_id);
    $stmt_q->execute();
    $result_q = $stmt_q->get_result();
    if ($question_data = $result_q->fetch_assoc()) {
        $question_text = $question_data['question'];
        $quiz_id = $question_data['quiz_id'];
    } else {
        // Question not found
        header('Location: manage_quizzes.php?error=question_not_found'); // Redirect to main quiz list if question invalid
        exit;
    }
    $stmt_q->close();
} else {
    error_log("Prepare failed for SELECT question text: " . $conn->error);
    header('Location: manage_quizzes.php?error=db_error');
    exit;
}

// --- Fetch Quiz Name (for context) ---
$quiz_name = '';
$stmt_quiz = $conn->prepare("SELECT name FROM quizzes WHERE id = ?");
if ($stmt_quiz) {
    $stmt_quiz->bind_param("i", $quiz_id);
    $stmt_quiz->execute();
    if ($quiz = $stmt_quiz->get_result()->fetch_assoc()) {
        $quiz_name = $quiz['name'];
    } // Quiz name is just for display, less critical if fetch fails
    $stmt_quiz->close();
}

// --- Fetch Options for this Question ---
$options = [];
// Add option_order later if needed for sorting options
$stmt_options = $conn->prepare("SELECT id, option_text, personality_type FROM options WHERE question_id = ? ORDER BY id ASC");
if ($stmt_options) {
    $stmt_options->bind_param("i", $question_id);
    $stmt_options->execute();
    $result_options = $stmt_options->get_result();
    while ($row = $result_options->fetch_assoc()) {
        $options[] = $row;
    }
    $stmt_options->close();
} else {
    error_log("Prepare failed for SELECT options: " . $conn->error);
    $page_error = "Database error fetching options.";
}

?>
<!DOCTYPE html>
<html>
<head>
    <title>Admin - Manage Options</title>
    <link rel="stylesheet" href="../style.css"> <!-- Link to your main CSS -->
    <style>
        /* Re-use or adapt styles */
        body { padding: 20px; font-family: sans-serif;}
        table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
        th, td { border: 1px solid #ccc; padding: 8px; text-align: left; vertical-align: top;}
        th { background-color: #f2f2f2; }
        td.option-text { max-width: 350px; word-wrap: break-word; }
        td.personality { width: 150px; }
        .actions a, .actions button { margin-right: 5px; text-decoration: none; padding: 2px 5px; border: 1px solid #ccc; border-radius: 3px; font-size: 0.9em; display: inline-block; margin-bottom: 3px;}
        .actions .delete-btn { color: red; border-color: red; background: none; cursor: pointer;}
        .add-link { display: inline-block; margin-top: 20px; padding: 10px 15px; background-color: #4CAF50; color: white; text-decoration: none; border-radius: 4px; }
        .nav-links { margin-bottom: 20px; }
        .nav-links a { margin-right: 10px; }
        .context { background-color: #eee; padding: 10px; margin-bottom: 15px; border-radius: 4px; }
        .error { color: red; font-weight: bold; }
    </style>
</head>
<body>
    <div class="nav-links">
        <a href="manage_questions.php?quiz_id=<?php echo $quiz_id; ?>">Back to Questions List</a> |
        <a href="dashboard.php">Admin Dashboard</a>
    </div>

    <h1>Manage Options</h1>
    <div class="context">
        <p><strong>Quiz:</strong> <?php echo htmlspecialchars($quiz_name); ?></p>
        <p><strong>Question:</strong> <?php echo nl2br(htmlspecialchars($question_text)); ?></p>
    </div>


    <?php if (isset($page_error)): ?>
        <p class="error"><?php echo htmlspecialchars($page_error); ?></p>
    <?php endif; ?>

    <?php if (!empty($options)): ?>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Option Text</th>
                    <th>Result Category (Type)</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($options as $option): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($option['id']); ?></td>
                        <td class="option-text"><?php echo htmlspecialchars($option['option_text']); ?></td>
                        <td class="personality"><?php echo htmlspecialchars($option['personality_type']); ?></td>
                        <td class="actions">
                            <a href="edit_option.php?id=<?php echo $option['id']; ?>&question_id=<?php echo $question_id; ?>">Edit</a> |
                            <!-- Delete Form -->
                            <form action="delete_option.php" method="POST" style="display:inline;" onsubmit="return confirm('Are you sure you want to delete this option?');">
                                <input type="hidden" name="id" value="<?php echo $option['id']; ?>">
                                <input type="hidden" name="question_id" value="<?php echo $question_id; // For redirection ?>">
                                <button type="submit" class="delete-btn">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php elseif (!isset($page_error)): ?>
        <p>No options found for this question yet.</p>
    <?php endif; ?>

    <a href="edit_option.php?question_id=<?php echo $question_id; ?>" class="add-link">Add New Option</a>

</body>
</html>
<?php
$conn->close(); // Close connection
?>
