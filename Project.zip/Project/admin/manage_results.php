<?php
// File: admin/manage_results.php

require_once __DIR__ . '/auth_check.php'; // Auth check and $conn

// --- Get and Validate Quiz ID ---
if (!isset($_GET['quiz_id']) || !filter_var($_GET['quiz_id'], FILTER_VALIDATE_INT)) {
    header('Location: manage_quizzes.php?error=invalid_quiz_id');
    exit;
}
$quiz_id = (int)$_GET['quiz_id'];

// --- Fetch Quiz Name ---
$quiz_name = '';
$stmt_quiz = $conn->prepare("SELECT name FROM quizzes WHERE id = ?");
if ($stmt_quiz) {
    $stmt_quiz->bind_param("i", $quiz_id);
    $stmt_quiz->execute();
    $result_quiz = $stmt_quiz->get_result();
    if ($quiz = $result_quiz->fetch_assoc()) {
        $quiz_name = $quiz['name'];
    } else {
        // Quiz not found
        header('Location: manage_quizzes.php?error=quiz_not_found');
        exit;
    }
    $stmt_quiz->close();
} else {
    error_log("Prepare failed for SELECT quiz name in manage_results: " . $conn->error);
    header('Location: manage_quizzes.php?error=db_error');
    exit;
}

// --- Fetch Result Definitions for this Quiz ---
$results = [];
$stmt_results = $conn->prepare("SELECT id, category_name, result_description, image_filename FROM result_definitions WHERE quiz_id = ? ORDER BY category_name ASC");
if ($stmt_results) {
    $stmt_results->bind_param("i", $quiz_id);
    $stmt_results->execute();
    $result_data = $stmt_results->get_result();
    while ($row = $result_data->fetch_assoc()) {
        $results[] = $row;
    }
    $stmt_results->close();
} else {
    error_log("Prepare failed for SELECT result definitions: " . $conn->error);
    $page_error = "Database error fetching result definitions.";
}

?>
<!DOCTYPE html>
<html>
<head>
    <title>Admin - Manage Results for "<?php echo htmlspecialchars($quiz_name); ?>"</title>
    <link rel="stylesheet" href="../style.css"> <!-- Link to your main CSS -->
    <style>
        /* Re-use or adapt styles */
        body { padding: 20px; font-family: sans-serif;}
        table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
        th, td { border: 1px solid #ccc; padding: 8px; text-align: left; vertical-align: top;}
        th { background-color: #f2f2f2; }
        td.description { max-width: 400px; word-wrap: break-word; }
        td.category { width: 150px; font-weight: bold; }
        td.image { width: 150px; word-wrap: break-word; }
        .actions a, .actions button { margin-right: 5px; text-decoration: none; padding: 2px 5px; border: 1px solid #ccc; border-radius: 3px; font-size: 0.9em; display: inline-block; margin-bottom: 3px;}
        .actions .delete-btn { color: red; border-color: red; background: none; cursor: pointer;}
        .add-link { display: inline-block; margin-top: 20px; padding: 10px 15px; background-color: #4CAF50; color: white; text-decoration: none; border-radius: 4px; }
        .nav-links { margin-bottom: 20px; }
        .nav-links a { margin-right: 10px; }
        .context { background-color: #eee; padding: 10px; margin-bottom: 15px; border-radius: 4px; }
        .error { color: red; font-weight: bold; }
        .note { font-size: 0.9em; color: #555; margin-top: 15px; }
    </style>
</head>
<body>
    <div class="nav-links">
        <a href="manage_quizzes.php">Back to Quiz List</a> |
        <a href="dashboard.php">Admin Dashboard</a>
    </div>

    <h1>Manage Result Definitions</h1>
     <div class="context">
        <p><strong>Quiz:</strong> <?php echo htmlspecialchars($quiz_name); ?></p>
    </div>

    <?php if (isset($page_error)): ?>
        <p class="error"><?php echo htmlspecialchars($page_error); ?></p>
    <?php endif; ?>

    <?php if (!empty($results)): ?>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Category Name<br><small>(Used in Options)</small></th>
                    <th>Result Description<br><small>(Shown to User)</small></th>
                    <th>Image Filename<br><small>(Optional)</small></th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($results as $result): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($result['id']); ?></td>
                        <td class="category"><?php echo htmlspecialchars($result['category_name']); ?></td>
                        <td class="description"><?php echo nl2br(htmlspecialchars($result['result_description'])); ?></td>
                        <td class="image"><?php echo htmlspecialchars($result['image_filename'] ?? ''); ?></td>
                        <td class="actions">
                            <a href="edit_result.php?id=<?php echo $result['id']; ?>&quiz_id=<?php echo $quiz_id; ?>">Edit</a> |
                            <!-- Delete Form -->
                            <form action="delete_result.php" method="POST" style="display:inline;" onsubmit="return confirm('Are you sure you want to delete this result definition? Make sure no options use this category name anymore!');">
                                <input type="hidden" name="id" value="<?php echo $result['id']; ?>">
                                <input type="hidden" name="quiz_id" value="<?php echo $quiz_id; // For redirection ?>">
                                <button type="submit" class="delete-btn">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php elseif (!isset($page_error)): ?>
        <p>No result definitions found for this quiz yet.</p>
    <?php endif; ?>

    <a href="edit_result.php?quiz_id=<?php echo $quiz_id; ?>" class="add-link">Add New Result Definition</a>

    <p class="note"><strong>Note:</strong> The 'Category Name' must exactly match the 'Result Category (Type)' selected when creating/editing options for this quiz's questions.</p>

</body>
</html>
<?php
$conn->close(); // Close connection
?>
