<?php
// File: admin/delete_option.php

require_once __DIR__ . '/auth_check.php'; // Auth check and $conn

// Check if the request method is POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: manage_quizzes.php'); // Redirect if not POST
    exit;
}

// Get and Validate Option ID from POST data
if (!isset($_POST['id']) || !filter_var($_POST['id'], FILTER_VALIDATE_INT)) {
    header('Location: manage_quizzes.php?error=invalid_opt_id'); // Redirect if ID invalid
    exit;
}
$option_id = (int)$_POST['id'];

// Get and Validate Question ID from POST data (for redirection)
if (!isset($_POST['question_id']) || !filter_var($_POST['question_id'], FILTER_VALIDATE_INT)) {
    // If question_id is missing, we can't redirect properly
    header('Location: manage_quizzes.php?error=missing_question_id_for_redirect');
    exit;
}
$question_id = (int)$_POST['question_id'];


// Prepare the DELETE statement
$stmt = $conn->prepare("DELETE FROM options WHERE id = ?");

if ($stmt) {
    $stmt->bind_param("i", $option_id);

    // Execute the statement
    if ($stmt->execute()) {
        // Check if any row was actually deleted
        if ($stmt->affected_rows > 0) {
            // Success! Redirect back to the options list
            header('Location: manage_options.php?question_id=' . $question_id . '&status=opt_deleted');
            exit;
        } else {
            // Option ID might not have existed
            header('Location: manage_options.php?question_id=' . $question_id . '&error=opt_not_found');
            exit;
        }
    } else {
        // Execution failed
        error_log("Execute failed for DELETE option: " . $stmt->error);
        header('Location: manage_options.php?question_id=' . $question_id . '&error=opt_delete_failed');
        exit;
    }
    $stmt->close();
} else {
    // Prepare failed
    error_log("Prepare failed for DELETE option: " . $conn->error);
    header('Location: manage_options.php?question_id=' . $question_id . '&error=db_error');
    exit;
}

$conn->close();

?>
