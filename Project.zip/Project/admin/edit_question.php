<?php
// File: admin/edit_question.php

require_once __DIR__ . '/auth_check.php'; // Auth check and $conn

// --- Get Quiz ID (Required) ---
if (isset($_REQUEST['quiz_id']) && filter_var($_REQUEST['quiz_id'], FILTER_VALIDATE_INT)) {
    $quiz_id = (int)$_REQUEST['quiz_id']; // Get from GET or POST
} else {
    header('Location: manage_quizzes.php?error=missing_quiz_id');
    exit;
}

// --- Fetch Quiz Name (for context) ---
$quiz_name = '';
$stmt_quiz = $conn->prepare("SELECT name FROM quizzes WHERE id = ?");
if ($stmt_quiz) {
    $stmt_quiz->bind_param("i", $quiz_id);
    $stmt_quiz->execute();
    $result_quiz = $stmt_quiz->get_result();
    if ($quiz = $result_quiz->fetch_assoc()) {
        $quiz_name = $quiz['name'];
    } else {
        header('Location: manage_quizzes.php?error=quiz_not_found');
        exit;
    }
    $stmt_quiz->close();
} // Error handling can be added here if needed

// --- Initialize variables ---
$question_id = null;
$question_text = '';
$question_order = 0; // Default order
$form_mode = 'Add';
$error_message = '';

// --- Check if editing an existing question ---
if (isset($_GET['id']) && filter_var($_GET['id'], FILTER_VALIDATE_INT)) {
    $question_id = (int)$_GET['id'];
    $form_mode = 'Edit';

    // Fetch existing question data
    $stmt = $conn->prepare("SELECT question, question_order FROM questions WHERE id = ? AND quiz_id = ?");
    if ($stmt) {
        $stmt->bind_param("ii", $question_id, $quiz_id);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($q_data = $result->fetch_assoc()) {
            $question_text = $q_data['question'];
            $question_order = $q_data['question_order'];
        } else {
            error_log("Admin tried to edit non-existent question ID: " . $question_id . " for quiz " . $quiz_id);
            header('Location: manage_questions.php?quiz_id=' . $quiz_id . '&error=q_not_found');
            exit;
        }
        $stmt->close();
    } else {
        error_log("Prepare failed for SELECT question: " . $conn->error);
        $error_message = "Database error fetching question details.";
        $form_mode = 'Error';
    }
} else {
    // If adding, find the next available order number
    $stmt_order = $conn->prepare("SELECT MAX(question_order) as max_order FROM questions WHERE quiz_id = ?");
    if ($stmt_order) {
        $stmt_order->bind_param("i", $quiz_id);
        $stmt_order->execute();
        $result_order = $stmt_order->get_result();
        $order_data = $result_order->fetch_assoc();
        $question_order = ($order_data && $order_data['max_order'] !== null) ? $order_data['max_order'] + 1 : 1; // Start at 1 if no questions yet
        $stmt_order->close();
    }
}


// --- Handle Form Submission (POST request) ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $form_mode !== 'Error') {
    // Get data from POST
    // quiz_id is already known
    $submitted_id = isset($_POST['id']) ? (int)$_POST['id'] : null;
    $submitted_text = trim($_POST['question'] ?? '');
    $submitted_order = isset($_POST['question_order']) ? (int)$_POST['question_order'] : 0;

    // Basic Validation
    if (empty($submitted_text)) {
        $error_message = "Question text cannot be empty.";
    } elseif ($submitted_order < 0) {
         $error_message = "Question order cannot be negative.";
    } else {
        // Decide whether to INSERT or UPDATE
        if ($submitted_id !== null && $submitted_id > 0) {
            // --- UPDATE existing question ---
            $stmt = $conn->prepare("UPDATE questions SET question = ?, question_order = ? WHERE id = ? AND quiz_id = ?");
            if ($stmt) {
                $stmt->bind_param("siii", $submitted_text, $submitted_order, $submitted_id, $quiz_id);
                if ($stmt->execute()) {
                    header('Location: manage_questions.php?quiz_id=' . $quiz_id . '&status=q_updated');
                    exit;
                } else {
                    error_log("Execute failed for UPDATE question: " . $stmt->error);
                    $error_message = "Failed to update question. Database error.";
                }
                $stmt->close();
            } else {
                error_log("Prepare failed for UPDATE question: " . $conn->error);
                $error_message = "Failed to update question. Database prepare error.";
            }
            // Keep submitted values on error
            $question_id = $submitted_id;
            $question_text = $submitted_text;
            $question_order = $submitted_order;

        } else {
            // --- INSERT new question ---
            $stmt = $conn->prepare("INSERT INTO questions (quiz_id, question, question_order) VALUES (?, ?, ?)");
            if ($stmt) {
                $stmt->bind_param("isi", $quiz_id, $submitted_text, $submitted_order);
                 if ($stmt->execute()) {
                    header('Location: manage_questions.php?quiz_id=' . $quiz_id . '&status=q_added');
                    exit;
                } else {
                    error_log("Execute failed for INSERT question: " . $stmt->error);
                    $error_message = "Failed to add question. Database error.";
                }
                $stmt->close();
            } else {
                 error_log("Prepare failed for INSERT question: " . $conn->error);
                 $error_message = "Failed to add question. Database prepare error.";
            }
             // Keep submitted values on error
            $question_text = $submitted_text;
            $question_order = $submitted_order;
        }
    }
    // If validation failed, keep submitted values
    if (!empty($error_message)) {
        $question_id = $submitted_id;
        $question_text = $submitted_text;
        $question_order = $submitted_order;
    }
} // End POST handling

?>
<!DOCTYPE html>
<html>
<head>
    <title>Admin - <?php echo $form_mode; ?> Question for "<?php echo htmlspecialchars($quiz_name); ?>"</title>
    <link rel="stylesheet" href="../style.css"> <!-- Link to your main CSS -->
    <style>
        /* Re-use or adapt styles from edit_quiz.php */
        body { padding: 20px; font-family: sans-serif; }
        .form-container { max-width: 600px; margin: 20px auto; padding: 20px; border: 1px solid #ccc; border-radius: 5px; background-color: #f9f9f9; }
        .form-container h1 { text-align: center; margin-bottom: 20px; }
        .form-group { margin-bottom: 15px; }
        .form-group label { display: block; margin-bottom: 5px; font-weight: bold; }
        .form-group textarea { width: 95%; padding: 8px; border: 1px solid #ccc; border-radius: 4px; min-height: 100px; }
        .form-group input[type="number"] { width: 100px; padding: 8px; border: 1px solid #ccc; border-radius: 4px; }
        .form-actions { text-align: center; margin-top: 20px; }
        .form-actions button { padding: 10px 20px; background-color: #4CAF50; color: white; border: none; border-radius: 4px; cursor: pointer; font-size: 16px; }
        .form-actions button:hover { background-color: #45a049; }
        .error { color: red; text-align: center; margin-bottom: 15px; font-weight: bold; }
        .nav-links { margin-bottom: 20px; }
        .nav-links a { margin-right: 10px; }
    </style>
</head>
<body>

<div class="form-container">
    <div class="nav-links">
        <a href="manage_questions.php?quiz_id=<?php echo $quiz_id; ?>">Back to Questions List</a> |
        <a href="dashboard.php">Admin Dashboard</a>
    </div>

    <h1><?php echo $form_mode; ?> Question</h1>
    <p>For Quiz: <strong><?php echo htmlspecialchars($quiz_name); ?></strong></p>

    <?php if ($error_message): ?>
        <p class="error"><?php echo htmlspecialchars($error_message); ?></p>
    <?php endif; ?>

    <?php if ($form_mode !== 'Error'): ?>
    <form action="edit_question.php" method="POST">
        <input type="hidden" name="quiz_id" value="<?php echo $quiz_id; ?>">
        <?php if ($question_id): // Include hidden ID field only when editing ?>
            <input type="hidden" name="id" value="<?php echo $question_id; ?>">
        <?php endif; ?>

        <div class="form-group">
            <label for="question">Question Text:</label>
            <textarea id="question" name="question" required><?php echo htmlspecialchars($question_text); ?></textarea>
        </div>

        <div class="form-group">
            <label for="question_order">Display Order:</label>
            <input type="number" id="question_order" name="question_order" value="<?php echo htmlspecialchars($question_order); ?>" min="0" required>
            <small>(Lower numbers appear first)</small>
        </div>

        <div class="form-actions">
            <button type="submit"><?php echo ($form_mode === 'Edit' ? 'Update' : 'Add'); ?> Question</button>
        </div>
    </form>
    <?php endif; ?>

</div>

</body>
</html>
<?php
$conn->close(); // Close the database connection
?>
