<?php
// File: admin/edit_option.php

require_once __DIR__ . '/auth_check.php'; // Auth check and $conn

// --- Get Question ID (Required) ---
if (isset($_REQUEST['question_id']) && filter_var($_REQUEST['question_id'], FILTER_VALIDATE_INT)) {
    $question_id = (int)$_REQUEST['question_id']; // Get from GET or POST
} else {
    header('Location: manage_quizzes.php?error=missing_question_id');
    exit;
}

// --- Fetch Question Text and Quiz ID ---
$question_text = '';
$quiz_id = null;
$stmt_q = $conn->prepare("SELECT question, quiz_id FROM questions WHERE id = ?");
if ($stmt_q) {
    $stmt_q->bind_param("i", $question_id);
    $stmt_q->execute();
    $result_q = $stmt_q->get_result();
    if ($question_data = $result_q->fetch_assoc()) {
        $question_text = $question_data['question'];
        $quiz_id = $question_data['quiz_id'];
    } else {
        header('Location: manage_quizzes.php?error=question_not_found');
        exit;
    }
    $stmt_q->close();
} else {
    error_log("Prepare failed for SELECT question text in edit_option: " . $conn->error);
    header('Location: manage_quizzes.php?error=db_error');
    exit;
}

// --- Fetch Quiz Name (for context) ---
$quiz_name = '';
$stmt_quiz = $conn->prepare("SELECT name FROM quizzes WHERE id = ?");
if ($stmt_quiz) {
    $stmt_quiz->bind_param("i", $quiz_id);
    $stmt_quiz->execute();
    if ($quiz = $stmt_quiz->get_result()->fetch_assoc()) {
        $quiz_name = $quiz['name'];
    }
    $stmt_quiz->close();
}

// --- Fetch Available Result Categories for this Quiz ---
$available_categories = [];
$stmt_cat = $conn->prepare("SELECT category_name FROM result_definitions WHERE quiz_id = ? ORDER BY category_name ASC");
if ($stmt_cat) {
    $stmt_cat->bind_param("i", $quiz_id);
    $stmt_cat->execute();
    $result_cat = $stmt_cat->get_result();
    while ($row = $result_cat->fetch_assoc()) {
        $available_categories[] = $row['category_name'];
    }
    $stmt_cat->close();
} else {
     error_log("Prepare failed for SELECT categories: " . $conn->error);
     $error_message = "Could not load result categories.";
     // Allow form display but show error and disable dropdown? Or redirect?
     // For now, let dropdown be empty if categories fail to load.
}
if (empty($available_categories) && !isset($error_message)) {
     $error_message = "No result categories defined for this quiz yet. Please add result definitions first.";
     // Consider disabling the form or redirecting if no categories exist.
}


// --- Initialize variables ---
$option_id = null;
$option_text = '';
$personality_type = ''; // Selected result category
$form_mode = 'Add';
// $error_message might be set above if categories failed

// --- Check if editing an existing option ---
if (isset($_GET['id']) && filter_var($_GET['id'], FILTER_VALIDATE_INT)) {
    $option_id = (int)$_GET['id'];
    $form_mode = 'Edit';

    // Fetch existing option data
    $stmt = $conn->prepare("SELECT option_text, personality_type FROM options WHERE id = ? AND question_id = ?");
    if ($stmt) {
        $stmt->bind_param("ii", $option_id, $question_id);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($o_data = $result->fetch_assoc()) {
            $option_text = $o_data['option_text'];
            $personality_type = $o_data['personality_type'];
        } else {
            error_log("Admin tried to edit non-existent option ID: " . $option_id . " for question " . $question_id);
            header('Location: manage_options.php?question_id=' . $question_id . '&error=opt_not_found');
            exit;
        }
        $stmt->close();
    } else {
        error_log("Prepare failed for SELECT option: " . $conn->error);
        $error_message = "Database error fetching option details.";
        $form_mode = 'Error';
    }
}

// --- Handle Form Submission (POST request) ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $form_mode !== 'Error') {
    // Get data from POST
    // question_id is already known
    $submitted_id = isset($_POST['id']) ? (int)$_POST['id'] : null;
    $submitted_text = trim($_POST['option_text'] ?? '');
    $submitted_type = trim($_POST['personality_type'] ?? '');

    // Basic Validation
    if (empty($submitted_text)) {
        $error_message = "Option text cannot be empty.";
    } elseif (empty($submitted_type)) {
         $error_message = "You must select a Result Category.";
    } elseif (!in_array($submitted_type, $available_categories)) {
         // Check if the submitted type is actually valid for this quiz
         $error_message = "Invalid Result Category selected.";
    } else {
        // Decide whether to INSERT or UPDATE
        if ($submitted_id !== null && $submitted_id > 0) {
            // --- UPDATE existing option ---
            $stmt = $conn->prepare("UPDATE options SET option_text = ?, personality_type = ? WHERE id = ? AND question_id = ?");
            if ($stmt) {
                $stmt->bind_param("ssii", $submitted_text, $submitted_type, $submitted_id, $question_id);
                if ($stmt->execute()) {
                    header('Location: manage_options.php?question_id=' . $question_id . '&status=opt_updated');
                    exit;
                } else {
                    error_log("Execute failed for UPDATE option: " . $stmt->error);
                    $error_message = "Failed to update option. Database error.";
                }
                $stmt->close();
            } else {
                error_log("Prepare failed for UPDATE option: " . $conn->error);
                $error_message = "Failed to update option. Database prepare error.";
            }
            // Keep submitted values on error
            $option_id = $submitted_id;
            $option_text = $submitted_text;
            $personality_type = $submitted_type;

        } else {
            // --- INSERT new option ---
            $stmt = $conn->prepare("INSERT INTO options (question_id, option_text, personality_type) VALUES (?, ?, ?)");
            if ($stmt) {
                $stmt->bind_param("iss", $question_id, $submitted_text, $submitted_type);
                 if ($stmt->execute()) {
                    header('Location: manage_options.php?question_id=' . $question_id . '&status=opt_added');
                    exit;
                } else {
                    error_log("Execute failed for INSERT option: " . $stmt->error);
                    $error_message = "Failed to add option. Database error.";
                }
                $stmt->close();
            } else {
                 error_log("Prepare failed for INSERT option: " . $conn->error);
                 $error_message = "Failed to add option. Database prepare error.";
            }
             // Keep submitted values on error
            $option_text = $submitted_text;
            $personality_type = $submitted_type;
        }
    }
    // If validation failed, keep submitted values
    if (!empty($error_message)) {
        $option_id = $submitted_id;
        $option_text = $submitted_text;
        $personality_type = $submitted_type;
    }
} // End POST handling

?>
<!DOCTYPE html>
<html>
<head>
    <title>Admin - <?php echo $form_mode; ?> Option</title>
    <link rel="stylesheet" href="../style.css"> <!-- Link to your main CSS -->
    <style>
        /* Re-use or adapt styles */
        body { padding: 20px; font-family: sans-serif; }
        .form-container { max-width: 600px; margin: 20px auto; padding: 20px; border: 1px solid #ccc; border-radius: 5px; background-color: #f9f9f9; }
        .form-container h1 { text-align: center; margin-bottom: 20px; }
        .form-group { margin-bottom: 15px; }
        .form-group label { display: block; margin-bottom: 5px; font-weight: bold; }
        .form-group input[type="text"],
        .form-group select {
            width: 95%; /* Adjust as needed */
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        .form-actions { text-align: center; margin-top: 20px; }
        .form-actions button { padding: 10px 20px; background-color: #4CAF50; color: white; border: none; border-radius: 4px; cursor: pointer; font-size: 16px; }
        .form-actions button:hover { background-color: #45a049; }
        .error { color: red; text-align: center; margin-bottom: 15px; font-weight: bold; }
        .nav-links { margin-bottom: 20px; }
        .nav-links a { margin-right: 10px; }
        .context { background-color: #eee; padding: 10px; margin-bottom: 15px; border-radius: 4px; }
    </style>
</head>
<body>

<div class="form-container">
    <div class="nav-links">
        <a href="manage_options.php?question_id=<?php echo $question_id; ?>">Back to Options List</a> |
        <a href="dashboard.php">Admin Dashboard</a>
    </div>

    <h1><?php echo $form_mode; ?> Option</h1>
     <div class="context">
        <p><strong>Quiz:</strong> <?php echo htmlspecialchars($quiz_name); ?></p>
        <p><strong>Question:</strong> <?php echo nl2br(htmlspecialchars($question_text)); ?></p>
    </div>

    <?php if (!empty($error_message)): ?>
        <p class="error"><?php echo htmlspecialchars($error_message); ?></p>
    <?php endif; ?>

    <?php if ($form_mode !== 'Error'): ?>
    <form action="edit_option.php" method="POST">
        <input type="hidden" name="question_id" value="<?php echo $question_id; ?>">
        <?php if ($option_id): // Include hidden ID field only when editing ?>
            <input type="hidden" name="id" value="<?php echo $option_id; ?>">
        <?php endif; ?>

        <div class="form-group">
            <label for="option_text">Option Text:</label>
            <input type="text" id="option_text" name="option_text" value="<?php echo htmlspecialchars($option_text); ?>" required>
        </div>

        <div class="form-group">
            <label for="personality_type">Result Category (Type):</label>
            <select id="personality_type" name="personality_type" required <?php echo empty($available_categories) ? 'disabled' : ''; ?>>
                <option value="">-- Select a Result Category --</option>
                <?php foreach ($available_categories as $category): ?>
                    <option value="<?php echo htmlspecialchars($category); ?>" <?php echo ($personality_type === $category) ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($category); ?>
                    </option>
                <?php endforeach; ?>
            </select>
             <?php if (empty($available_categories)): ?>
                <small style="color: #888;">(No result categories found for this quiz. Add them via "Manage Results" on the quiz list page.)</small>
             <?php endif; ?>
        </div>

        <div class="form-actions">
            <button type="submit" <?php echo empty($available_categories) ? 'disabled' : ''; ?>>
                <?php echo ($form_mode === 'Edit' ? 'Update' : 'Add'); ?> Option
            </button>
        </div>
    </form>
    <?php endif; ?>

</div>

</body>
</html>
<?php
$conn->close(); // Close the database connection
?>
