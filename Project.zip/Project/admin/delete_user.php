<?php
// File: admin/delete_user.php

require_once __DIR__ . '/auth_check.php'; // Auth check and $conn

// 1. Check if the request method is POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    // If not POST, redirect back - don't allow deletion via GET
    header('Location: manage_users.php');
    exit;
}

// 2. Get and Validate User ID from POST data
if (!isset($_POST['id']) || !filter_var($_POST['id'], FILTER_VALIDATE_INT)) {
    // If ID is missing or not an integer, redirect back with an error
    header('Location: manage_users.php?error=invalid_user_id');
    exit;
}
$user_id_to_delete = (int)$_POST['id'];
$current_admin_id = $_SESSION['user_id']; // Get current admin's ID

// 3. CRITICAL: Prevent self-deletion
if ($user_id_to_delete === $current_admin_id) {
    header('Location: manage_users.php?error=cannot_delete_self');
    exit;
}

// --- Optional: Add other checks, e.g., prevent deleting user ID 1 if it's a super admin ---
// if ($user_id_to_delete === 1) {
//     header('Location: manage_users.php?error=cannot_delete_super_admin');
//     exit;
// }

// 4. Prepare the DELETE statement
// Consider related data: What happens to quiz_answers from this user?
// You might want to keep them, or set user_id to NULL (requires ALTER TABLE), or delete them (requires CASCADE or manual delete).
// For now, we just delete the user.
$stmt = $conn->prepare("DELETE FROM users WHERE id = ?");

if ($stmt) {
    $stmt->bind_param("i", $user_id_to_delete);

    // 5. Execute the statement
    if ($stmt->execute()) {
        // Check if any row was actually deleted
        if ($stmt->affected_rows > 0) {
            // Success! Redirect back to the list with a success status
            header('Location: manage_users.php?status=user_deleted');
            exit;
        } else {
            // User ID might not have existed (already deleted?)
            header('Location: manage_users.php?error=user_not_found');
            exit;
        }
    } else {
        // Execution failed (less likely here unless DB issue)
        error_log("Execute failed for DELETE user: " . $stmt->error);
        header('Location: manage_users.php?error=user_delete_failed');
        exit;
    }
    $stmt->close();
} else {
    // Prepare failed
    error_log("Prepare failed for DELETE user: " . $conn->error);
    header('Location: manage_users.php?error=db_error');
    exit;
}

$conn->close();

?>
