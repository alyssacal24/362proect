<?php
session_start();
// Redirect if not logged in OR not an admin
if (!isset($_SESSION['user_id']) || !isset($_SESSION['is_admin']) || $_SESSION['is_admin'] !== true) {
    // Redirect to login or an 'access denied' page
    header('Location: ../login/login.php?error=admin_required');
    exit;
}
// Include DB connection for admin pages that need it
// Use a relative path from the admin folder
require_once __DIR__ . '/../db_connection.php'; // Use your existing connection file
?>
