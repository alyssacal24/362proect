<?php
// File: admin/delete_quiz.php

// 1. Include Auth Check and DB Connection
// This also starts the session and provides the $conn variable.
require_once __DIR__ . '/auth_check.php';

// 2. Check if the request method is POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    // If not POST, redirect back - don't allow deletion via GET
    header('Location: manage_quizzes.php');
    exit;
}

// 3. Get and Validate Quiz ID from POST data
if (!isset($_POST['id']) || !filter_var($_POST['id'], FILTER_VALIDATE_INT)) {
    // If ID is missing or not an integer, redirect back with an error
    header('Location: manage_quizzes.php?error=invalid_id');
    exit;
}
$quiz_id = (int)$_POST['id'];

// --- Optional: Add extra checks here if needed, e.g., prevent deleting quiz ID 1 ---
// if ($quiz_id === 1) {
//     header('Location: manage_quizzes.php?error=cannot_delete_default');
//     exit;
// }

// 4. Prepare the DELETE statement
// Assumes ON DELETE CASCADE is set for related tables (questions, options, etc.)
$stmt = $conn->prepare("DELETE FROM quizzes WHERE id = ?");

if ($stmt) {
    $stmt->bind_param("i", $quiz_id);

    // 5. Execute the statement
    if ($stmt->execute()) {
        // Check if any row was actually deleted
        if ($stmt->affected_rows > 0) {
            // Success! Redirect back to the list with a success status
            header('Location: manage_quizzes.php?status=deleted');
            exit;
        } else {
            // Quiz ID might not have existed (already deleted?)
            header('Location: manage_quizzes.php?error=not_found_or_no_change');
            exit;
        }
    } else {
        // Execution failed (e.g., foreign key constraint if CASCADE not set)
        error_log("Execute failed for DELETE in delete_quiz.php: " . $stmt->error);
        header('Location: manage_quizzes.php?error=delete_failed');
        exit;
    }
    $stmt->close();
} else {
    // Prepare failed
    error_log("Prepare failed for DELETE in delete_quiz.php: " . $conn->error);
    header('Location: manage_quizzes.php?error=db_error');
    exit;
}

// Close connection (optional here as script exits, but good practice)
$conn->close();

?>
