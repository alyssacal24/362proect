<?php require_once __DIR__ . '/auth_check.php'; // Includes session_start() and DB connection ($conn)

// Fetch quizzes (assuming you added is_active column)
$result = $conn->query("SELECT id, name, is_active FROM quizzes ORDER BY name ASC"); // Use $conn from included file

?>
<!DOCTYPE html>
<html>
<head>
    <title>Admin - Manage Quizzes</title>
    <link rel="stylesheet" href="../style.css"> <!-- Link to your main CSS -->
    <style>
        /* Add specific admin styles if needed */
        body { padding: 20px; }
        table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
        th, td { border: 1px solid #ccc; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; }
        .actions a, .actions button { margin-right: 5px; text-decoration: none; padding: 2px 5px; border: 1px solid #ccc; border-radius: 3px; font-size: 0.9em;}
        .actions .delete-btn { color: red; border-color: red;}
        .add-link { display: inline-block; margin-top: 20px; padding: 10px 15px; background-color: #4CAF50; color: white; text-decoration: none; border-radius: 4px; }
    </style>
</head>
<body>
    <h1>Manage Quizzes</h1>
    <p><a href="dashboard.php">Back to Admin Dashboard</a> | <a href="../index.php">View Main Site</a></p>

    <?php if ($result && $result->num_rows > 0): ?>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['id']); ?></td>
                        <td><?php echo htmlspecialchars($row['name']); ?></td>
                        <td><?php echo $row['is_active'] ? 'Active' : 'Inactive'; ?></td>
                        <td class="actions">
                            <a href="edit_quiz.php?id=<?php echo $row['id']; ?>">Edit Details</a> |
                            <a href="manage_questions.php?quiz_id=<?php echo $row['id']; ?>">Questions</a> |
                            <a href="manage_results.php?quiz_id=<?php echo $row['id']; ?>">Results</a> |
                            <!-- Add Toggle Active/Inactive Link/Form -->
                            <a href="toggle_quiz_active.php?id=<?php echo $row['id']; ?>"><?php echo $row['is_active'] ? 'Deactivate' : 'Activate'; ?></a> |
                            <!-- Add Delete Form with Confirmation -->
                            <form action="delete_quiz.php" method="POST" style="display:inline;" onsubmit="return confirm('Are you sure you want to delete this quiz and ALL its questions/options/results?');">
                                <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                                <button type="submit" class="delete-btn">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>No quizzes found.</p>
    <?php endif; ?>

    <a href="edit_quiz.php" class="add-link">Add New Quiz</a>

</body>
</html>
<?php
$conn->close(); // Close connection
?>
