<?php
// File: admin/edit_quiz.php

// 1. Include Auth Check and DB Connection
require_once __DIR__ . '/auth_check.php'; // Provides $conn and ensures admin access

// --- Initialize variables ---
$quiz_id = null;
$quiz_name = '';
$quiz_description = '';
$quiz_is_active = 1; // Default to active for new quizzes
$form_mode = 'Add'; // Default mode is 'Add'
$error_message = '';
$success_message = ''; // Optional: for displaying success feedback

// --- Check if editing an existing quiz ---
if (isset($_GET['id']) && filter_var($_GET['id'], FILTER_VALIDATE_INT)) {
    $quiz_id = (int)$_GET['id'];
    $form_mode = 'Edit';

    // Fetch existing quiz data
    $stmt = $conn->prepare("SELECT name, description, is_active FROM quizzes WHERE id = ?");
    if ($stmt) {
        $stmt->bind_param("i", $quiz_id);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($quiz_data = $result->fetch_assoc()) {
            $quiz_name = $quiz_data['name'];
            $quiz_description = $quiz_data['description'];
            $quiz_is_active = $quiz_data['is_active'];
        } else {
            // Quiz ID not found, redirect or show error
            error_log("Admin tried to edit non-existent quiz ID: " . $quiz_id);
            header('Location: manage_quizzes.php?error=not_found');
            exit;
        }
        $stmt->close();
    } else {
        error_log("Prepare failed for SELECT in edit_quiz.php: " . $conn->error);
        $error_message = "Database error fetching quiz details.";
        // Avoid proceeding without data if there was a DB error
        $form_mode = 'Error';
    }
}

// --- Handle Form Submission (POST request) ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $form_mode !== 'Error') {
    // Get data from POST
    $submitted_id = isset($_POST['id']) ? (int)$_POST['id'] : null;
    $submitted_name = trim($_POST['name'] ?? '');
    $submitted_description = trim($_POST['description'] ?? '');
    // Checkbox value: '1' if checked, not present if unchecked
    $submitted_is_active = isset($_POST['is_active']) ? 1 : 0;

    // Basic Validation
    if (empty($submitted_name)) {
        $error_message = "Quiz Name is required.";
        // --- FIX: Keep submitted values when validation fails ---
        // Keep the other values the user submitted so they don't have to re-enter them
        $quiz_id = $submitted_id; // Preserve ID if editing
        $quiz_name = $submitted_name; // Will be empty, showing the validation issue
        $quiz_description = $submitted_description;
        $quiz_is_active = $submitted_is_active;
        // --- End of FIX ---
    } else {
        // Validation passed, proceed with DB operation
        // Decide whether to INSERT or UPDATE
        if ($submitted_id !== null && $submitted_id > 0) {
            // --- UPDATE existing quiz ---
            $stmt = $conn->prepare("UPDATE quizzes SET name = ?, description = ?, is_active = ? WHERE id = ?");
            if ($stmt) {
                $stmt->bind_param("ssii", $submitted_name, $submitted_description, $submitted_is_active, $submitted_id);
                if ($stmt->execute()) {
                    // Success! Redirect back to the list
                    header('Location: manage_quizzes.php?status=updated');
                    exit;
                } else {
                    error_log("Execute failed for UPDATE in edit_quiz.php: " . $stmt->error);
                    $error_message = "Failed to update quiz. Database error.";
                }
                $stmt->close();
            } else {
                error_log("Prepare failed for UPDATE in edit_quiz.php: " . $conn->error);
                $error_message = "Failed to update quiz. Database prepare error.";
            }
            // Keep submitted values in form fields on DB error
            $quiz_id = $submitted_id;
            $quiz_name = $submitted_name;
            $quiz_description = $submitted_description;
            $quiz_is_active = $submitted_is_active;

        } else {
            // --- INSERT new quiz ---
            $stmt = $conn->prepare("INSERT INTO quizzes (name, description, is_active) VALUES (?, ?, ?)");
            if ($stmt) {
                $stmt->bind_param("ssi", $submitted_name, $submitted_description, $submitted_is_active);
                 if ($stmt->execute()) {
                    // Success! Redirect back to the list
                    header('Location: manage_quizzes.php?status=added');
                    exit;
                } else {
                    error_log("Execute failed for INSERT in edit_quiz.php: " . $stmt->error);
                    $error_message = "Failed to add quiz. Database error.";
                }
                $stmt->close();
            } else {
                 error_log("Prepare failed for INSERT in edit_quiz.php: " . $conn->error);
                 $error_message = "Failed to add quiz. Database prepare error.";
            }
             // Keep submitted values in form fields on DB error
            // No need to set $quiz_id here as it's null for insert
            $quiz_name = $submitted_name;
            $quiz_description = $submitted_description;
            $quiz_is_active = $submitted_is_active;
        } // End INSERT/UPDATE else
    } // End validation else

    // --- REMOVED THE EXTRA INVALID 'else' BLOCK THAT WAS HERE ---

} // End POST handling

?>
<!DOCTYPE html>
<html>
<head>
    <title>Admin - <?php echo $form_mode; ?> Quiz</title>
    <link rel="stylesheet" href="../style.css"> <!-- Link to your main CSS -->
    <style>
        /* Add specific admin styles if needed */
        body { padding: 20px; font-family: sans-serif; }
        .form-container { max-width: 600px; margin: 20px auto; padding: 20px; border: 1px solid #ccc; border-radius: 5px; background-color: #f9f9f9; }
        .form-container h1 { text-align: center; margin-bottom: 20px; }
        .form-group { margin-bottom: 15px; }
        .form-group label { display: block; margin-bottom: 5px; font-weight: bold; }
        .form-group input[type="text"],
        .form-group textarea {
            width: 95%; /* Adjust as needed */
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        .form-group textarea { min-height: 80px; }
        .form-group input[type="checkbox"] { margin-right: 5px; }
        .form-actions { text-align: center; margin-top: 20px; }
        .form-actions button { padding: 10px 20px; background-color: #4CAF50; color: white; border: none; border-radius: 4px; cursor: pointer; font-size: 16px; }
        .form-actions button:hover { background-color: #45a049; }
        .error { color: red; text-align: center; margin-bottom: 15px; font-weight: bold; }
        .nav-links { margin-bottom: 20px; }
        .nav-links a { margin-right: 10px; }
    </style>
</head>
<body>

<div class="form-container">
    <div class="nav-links">
        <a href="manage_quizzes.php">Back to Quiz List</a> |
        <a href="dashboard.php">Admin Dashboard</a>
    </div>

    <h1><?php echo $form_mode; ?> Quiz</h1>

    <?php if ($error_message): ?>
        <p class="error"><?php echo htmlspecialchars($error_message); ?></p>
    <?php endif; ?>

    <?php if ($form_mode !== 'Error'): // Don't show form if initial DB fetch failed ?>
    <form action="edit_quiz.php<?php echo ($quiz_id ? '?id=' . $quiz_id : ''); ?>" method="POST">
        <?php if ($quiz_id): // Include hidden ID field only when editing ?>
            <input type="hidden" name="id" value="<?php echo $quiz_id; ?>">
        <?php endif; ?>

        <div class="form-group">
            <label for="name">Quiz Name:</label>
            <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($quiz_name); ?>" required>
        </div>

        <div class="form-group">
            <label for="description">Description:</label>
            <textarea id="description" name="description"><?php echo htmlspecialchars($quiz_description); ?></textarea>
        </div>

        <div class="form-group">
            <label for="is_active">
                <input type="checkbox" id="is_active" name="is_active" value="1" <?php echo ($quiz_is_active == 1) ? 'checked' : ''; ?>>
                Active (Quiz will be visible to users)
            </label>
        </div>

        <div class="form-actions">
            <button type="submit"><?php echo ($form_mode === 'Edit' ? 'Update' : 'Add'); ?> Quiz</button>
        </div>
    </form>
    <?php endif; // End check for form_mode !== 'Error' ?>

</div>

</body>
</html>
<?php
$conn->close(); // Close the database connection
?>
