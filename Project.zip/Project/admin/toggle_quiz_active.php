<?php
// File: admin/toggle_quiz_active.php

// 1. Include Auth Check and DB Connection
// This also starts the session and provides the $conn variable.
require_once __DIR__ . '/auth_check.php';

// 2. Get and Validate Quiz ID from URL parameter
if (!isset($_GET['id']) || !filter_var($_GET['id'], FILTER_VALIDATE_INT)) {
    // If ID is missing or not an integer, redirect back with an error (optional)
    // For simplicity, just redirecting back to the list for now.
    // You could add session flash messages later for better UX.
    header('Location: manage_quizzes.php');
    exit;
}
$quiz_id = (int)$_GET['id'];

// 3. Fetch the current status of the quiz
$current_status = null;
$stmt_select = $conn->prepare("SELECT is_active FROM quizzes WHERE id = ?");
if ($stmt_select) {
    $stmt_select->bind_param("i", $quiz_id);
    $stmt_select->execute();
    $result = $stmt_select->get_result();
    if ($row = $result->fetch_assoc()) {
        $current_status = $row['is_active'];
    }
    $stmt_select->close();
} else {
    // Handle prepare error (log it, show generic message, etc.)
    error_log("Prepare failed for SELECT in toggle_quiz_active: " . $conn->error);
    // Redirect back as we can't proceed
    header('Location: manage_quizzes.php?error=db_error');
    exit;
}

// 4. Check if the quiz was found
if ($current_status === null) {
    // Quiz ID doesn't exist in the database
    header('Location: manage_quizzes.php?error=not_found');
    exit;
}

// 5. Determine the new status (toggle)
$new_status = ($current_status == 1) ? 0 : 1;

// 6. Prepare and Execute the Update statement
$stmt_update = $conn->prepare("UPDATE quizzes SET is_active = ? WHERE id = ?");
if ($stmt_update) {
    $stmt_update->bind_param("ii", $new_status, $quiz_id);
    $success = $stmt_update->execute();
    $stmt_update->close();

    if (!$success) {
        // Handle execution error
        error_log("Execute failed for UPDATE in toggle_quiz_active: " . $stmt_update->error);
        header('Location: manage_quizzes.php?error=update_failed');
        exit;
    }
} else {
    // Handle prepare error
    error_log("Prepare failed for UPDATE in toggle_quiz_active: " . $conn->error);
    header('Location: manage_quizzes.php?error=db_error');
    exit;
}

// 7. Redirect back to the manage quizzes page on success
// Optional: Add a success message parameter if needed
header('Location: manage_quizzes.php?status=toggled');
exit;

?>
