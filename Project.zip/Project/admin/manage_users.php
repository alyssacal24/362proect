<?php
// File: admin/manage_users.php

require_once __DIR__ . '/auth_check.php'; // Auth check and $conn

// --- Fetch all users ---
$users = [];
// Exclude the currently logged-in admin if you want to prevent self-modification easily
// $current_admin_id = $_SESSION['user_id'];
// $stmt_users = $conn->prepare("SELECT id, username, role FROM users WHERE id != ? ORDER BY username ASC");
// $stmt_users->bind_param("i", $current_admin_id);

// Or fetch all users and handle self-modification prevention in the loop
$stmt_users = $conn->prepare("SELECT id, username, role FROM users ORDER BY username ASC");

if ($stmt_users) {
    $stmt_users->execute();
    $result_users = $stmt_users->get_result();
    while ($row = $result_users->fetch_assoc()) {
        $users[] = $row;
    }
    $stmt_users->close();
} else {
    error_log("Prepare failed for SELECT users: " . $conn->error);
    $page_error = "Database error fetching users.";
}

// --- Handle Role Change (if submitted) ---
// We can handle this on the same page for simplicity or create a separate script
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'change_role') {
    if (isset($_POST['user_id'], $_POST['new_role']) && filter_var($_POST['user_id'], FILTER_VALIDATE_INT)) {
        $user_id_to_change = (int)$_POST['user_id'];
        $new_role = $_POST['new_role'];
        $current_admin_id = $_SESSION['user_id']; // Get current admin's ID

        // Validation: Ensure role is valid ('admin' or 'user')
        if ($new_role !== 'admin' && $new_role !== 'user') {
            $page_error = "Invalid role specified.";
        }
        // Validation: Prevent admin from demoting themselves (important!)
        elseif ($user_id_to_change === $current_admin_id && $new_role !== 'admin') {
             $page_error = "You cannot remove your own admin privileges.";
        }
        else {
            // Proceed with update
            $stmt_update = $conn->prepare("UPDATE users SET role = ? WHERE id = ?");
            if ($stmt_update) {
                $stmt_update->bind_param("si", $new_role, $user_id_to_change);
                if ($stmt_update->execute()) {
                    // Role changed successfully, redirect to refresh the list
                    header('Location: manage_users.php?status=role_changed');
                    exit;
                } else {
                    error_log("Execute failed for UPDATE user role: " . $stmt_update->error);
                    $page_error = "Failed to change user role. Database error.";
                }
                $stmt_update->close();
            } else {
                error_log("Prepare failed for UPDATE user role: " . $conn->error);
                $page_error = "Failed to change user role. Database prepare error.";
            }
        }
    } else {
        $page_error = "Invalid data submitted for role change.";
    }
}


?>
<!DOCTYPE html>
<html>
<head>
    <title>Admin - Manage Users</title>
    <link rel="stylesheet" href="../style.css"> <!-- Link to your main CSS -->
    <style>
        /* Re-use or adapt styles */
        body { padding: 20px; font-family: sans-serif;}
        table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
        th, td { border: 1px solid #ccc; padding: 8px; text-align: left; vertical-align: middle;} /* Use middle align */
        th { background-color: #f2f2f2; }
        .actions form { display: inline-block; margin-right: 5px; }
        .actions select { padding: 3px; }
        .actions button { padding: 3px 6px; cursor: pointer; }
        .actions .delete-btn { color: red; border-color: red; background: none; }
        .nav-links { margin-bottom: 20px; }
        .nav-links a { margin-right: 10px; }
        .error { color: red; font-weight: bold; margin-bottom: 15px; }
        .success { color: green; font-weight: bold; margin-bottom: 15px; }
        .note { font-size: 0.9em; color: #555; margin-top: 15px; }
    </style>
</head>
<body>
    <div class="nav-links">
        <a href="dashboard.php">Back to Admin Dashboard</a> |
        <a href="../index.php">View Main Site</a>
    </div>

    <h1>Manage Users</h1>

    <?php if (isset($_GET['status']) && $_GET['status'] === 'role_changed'): ?>
        <p class="success">User role updated successfully.</p>
    <?php endif; ?>
     <?php if (isset($_GET['status']) && $_GET['status'] === 'user_deleted'): ?>
        <p class="success">User deleted successfully.</p>
    <?php endif; ?>
    <?php if (isset($page_error)): ?>
        <p class="error"><?php echo htmlspecialchars($page_error); ?></p>
    <?php endif; ?>
     <?php if (isset($_GET['error'])): // Display errors passed via URL ?>
        <p class="error"><?php echo htmlspecialchars($_GET['error']); ?></p>
    <?php endif; ?>


    <?php if (!empty($users)): ?>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Username</th>
                    <th>Current Role</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($users as $user):
                    $is_current_admin = ($user['id'] === $_SESSION['user_id']);
                ?>
                    <tr>
                        <td><?php echo htmlspecialchars($user['id']); ?></td>
                        <td><?php echo htmlspecialchars($user['username']); ?></td>
                        <td><?php echo htmlspecialchars($user['role']); ?></td>
                        <td class="actions">
                            <!-- Change Role Form -->
                            <form action="manage_users.php" method="POST" style="display:inline;">
                                <input type="hidden" name="action" value="change_role">
                                <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                <select name="new_role" <?php echo $is_current_admin ? 'title="Cannot change your own role here"' : ''; ?>>
                                    <option value="user" <?php echo ($user['role'] === 'user') ? 'selected' : ''; ?>>User</option>
                                    <option value="admin" <?php echo ($user['role'] === 'admin') ? 'selected' : ''; ?>>Admin</option>
                                </select>
                                <button type="submit" <?php echo ($is_current_admin && $user['role'] === 'admin') ? 'disabled title="Cannot demote yourself"' : ''; ?>>
                                    Change Role
                                </button>
                            </form>

                            | <!-- Separator -->

                            <!-- Delete User Form -->
                            <form action="delete_user.php" method="POST" style="display:inline;" onsubmit="return confirm('VERY DANGEROUS! Are you absolutely sure you want to delete user \'<?php echo htmlspecialchars(addslashes($user['username'])); ?>\'? This cannot be undone.');">
                                <input type="hidden" name="id" value="<?php echo $user['id']; ?>">
                                <button type="submit" class="delete-btn" <?php echo $is_current_admin ? 'disabled title="Cannot delete yourself"' : ''; ?>>
                                    Delete User
                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php elseif (!isset($page_error)): ?>
        <p>No users found.</p>
    <?php endif; ?>

    <p class="note"><strong>Note:</strong> You cannot delete your own admin account or change your own role to 'user' from this page.</p>

</body>
</html>
<?php
$conn->close(); // Close connection
?>
