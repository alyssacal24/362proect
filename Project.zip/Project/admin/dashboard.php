<?php
// File: admin/dashboard.php

// --- ENABLE ERROR REPORTING (Optional but helpful for initial setup) ---
// ini_set('display_errors', 1);
// ini_set('display_startup_errors', 1);
// error_reporting(E_ALL);
// ---------------------------------------------

// 1. Include Auth Check - This is ESSENTIAL
// It ensures only logged-in admins can see this page and includes db connection ($conn)
require_once __DIR__ . '/auth_check.php';

// You could fetch some stats here later (e.g., number of quizzes, users)
// $quiz_count_result = $conn->query("SELECT COUNT(*) as count FROM quizzes");
// $quiz_count = ($quiz_count_result) ? $quiz_count_result->fetch_assoc()['count'] : 0;
// $user_count_result = $conn->query("SELECT COUNT(*) as count FROM users");
// $user_count = ($user_count_result) ? $user_count_result->fetch_assoc()['count'] : 0;

?>
<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="../style.css"> <!-- Link to your main CSS -->
    <style>
        /* Basic Admin Dashboard Styles */
        body { padding: 20px; font-family: sans-serif; }
        .dashboard-container { max-width: 800px; margin: 20px auto; }
        h1 { text-align: center; margin-bottom: 30px; }
        .admin-menu { list-style: none; padding: 0; text-align: center; }
        .admin-menu li { margin-bottom: 15px; }
        .admin-menu a {
            display: inline-block;
            padding: 12px 25px;
            background-color: #5bc0de; /* Info blue */
            color: white;
            text-decoration: none;
            border-radius: 5px;
            min-width: 200px;
            transition: background-color 0.2s;
        }
        .admin-menu a:hover { background-color: #31b0d5; }
        .logout-link { text-align: center; margin-top: 30px; }
        .logout-link a { color: #d9534f; } /* Danger red */
        .welcome-msg { text-align: center; margin-bottom: 20px; font-size: 1.1em; }
    </style>
</head>
<body>

<div class="dashboard-container">
    <h1>Admin Dashboard</h1>

    <p class="welcome-msg">Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?>!</p>

    <ul class="admin-menu">
        <li><a href="manage_quizzes.php">Manage Quizzes</a></li>
        <li><a href="manage_users.php">Manage Users</a></li>
        <li><a href="view_quiz_data.php">View Quiz Results</a></li>
        <li><a href="../index.php" style="background-color: #777;">View Main Site</a></li>
    </ul>

    <p class="logout-link">
        <a href="../login/logout.php">Logout</a>
    </p>

</div>

</body>
</html>
<?php
// Optional: Close connection if you fetched stats
// if (isset($conn)) { $conn->close(); }
?>
