<?php
// File: admin/view_quiz_data.php

require_once __DIR__ . '/auth_check.php'; // Auth check and $conn

// --- Fetch list of quizzes for filtering ---
$quizzes = [];
$stmt_quizzes = $conn->prepare("SELECT id, name FROM quizzes ORDER BY name ASC");
if ($stmt_quizzes) {
    $stmt_quizzes->execute();
    $result_quizzes = $stmt_quizzes->get_result();
    while ($row = $result_quizzes->fetch_assoc()) {
        $quizzes[] = $row;
    }
    $stmt_quizzes->close();
} else {
    error_log("Prepare failed for SELECT quizzes list: " . $conn->error);
    // Non-fatal error, filtering just won't work
}

// --- Filtering Logic ---
$filter_quiz_id = null;
$filter_active = false;
if (isset($_GET['filter_quiz_id']) && filter_var($_GET['filter_quiz_id'], FILTER_VALIDATE_INT) && $_GET['filter_quiz_id'] > 0) {
    $filter_quiz_id = (int)$_GET['filter_quiz_id'];
    $filter_active = true;
}

// --- Fetch Quiz Answers ---
$quiz_results = [];
$sql = "SELECT qa.id, qa.result, qa.created_at, u.username, q.name as quiz_name
        FROM quiz_answers qa
        JOIN users u ON qa.user_id = u.id
        JOIN quizzes q ON qa.quiz_id = q.id";

$params = [];
$types = '';

if ($filter_active) {
    $sql .= " WHERE qa.quiz_id = ?";
    $params[] = $filter_quiz_id;
    $types .= 'i';
}

$sql .= " ORDER BY qa.created_at DESC LIMIT 100"; // Limit results for performance

$stmt_results = $conn->prepare($sql);

if ($stmt_results) {
    if ($filter_active) {
        $stmt_results->bind_param($types, ...$params);
    }
    $stmt_results->execute();
    $result_data = $stmt_results->get_result();
    while ($row = $result_data->fetch_assoc()) {
        $quiz_results[] = $row;
    }
    $stmt_results->close();
} else {
    error_log("Prepare failed for SELECT quiz answers: " . $conn->error);
    $page_error = "Database error fetching quiz results.";
}


?>
<!DOCTYPE html>
<html>
<head>
    <title>Admin - View Quiz Results</title>
    <link rel="stylesheet" href="../style.css"> <!-- Link to your main CSS -->
    <style>
        /* Re-use or adapt styles */
        body { padding: 20px; font-family: sans-serif;}
        table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
        th, td { border: 1px solid #ccc; padding: 8px; text-align: left; vertical-align: top;}
        th { background-color: #f2f2f2; }
        td.result-text { max-width: 400px; word-wrap: break-word; }
        td.timestamp { width: 160px; }
        td.user { width: 120px; }
        td.quiz { width: 180px; }
        .nav-links { margin-bottom: 20px; }
        .nav-links a { margin-right: 10px; }
        .filter-form { margin-bottom: 20px; background-color: #f9f9f9; padding: 15px; border: 1px solid #eee; border-radius: 4px;}
        .filter-form label { margin-right: 5px; font-weight: bold;}
        .filter-form select { padding: 5px; }
        .filter-form button { padding: 5px 10px; cursor: pointer; margin-left: 10px;}
        .error { color: red; font-weight: bold; margin-bottom: 15px; }
        .note { font-size: 0.9em; color: #555; margin-top: 15px; }
    </style>
</head>
<body>
    <div class="nav-links">
        <a href="dashboard.php">Back to Admin Dashboard</a> |
        <a href="../index.php">View Main Site</a>
    </div>

    <h1>View Quiz Results</h1>

    <!-- Filter Form -->
    <form action="view_quiz_data.php" method="GET" class="filter-form">
        <label for="filter_quiz_id">Filter by Quiz:</label>
        <select name="filter_quiz_id" id="filter_quiz_id">
            <option value="">-- All Quizzes --</option>
            <?php foreach ($quizzes as $quiz): ?>
                <option value="<?php echo $quiz['id']; ?>" <?php echo ($filter_quiz_id === $quiz['id']) ? 'selected' : ''; ?>>
                    <?php echo htmlspecialchars($quiz['name']); ?>
                </option>
            <?php endforeach; ?>
        </select>
        <button type="submit">Filter</button>
        <?php if ($filter_active): ?>
            <a href="view_quiz_data.php" style="margin-left: 10px;">Clear Filter</a>
        <?php endif; ?>
    </form>


    <?php if (isset($page_error)): ?>
        <p class="error"><?php echo htmlspecialchars($page_error); ?></p>
    <?php endif; ?>

    <?php if (!empty($quiz_results)): ?>
        <p>Showing the latest <?php echo count($quiz_results); ?> results <?php echo $filter_active ? 'for the selected quiz' : ''; ?>.</p>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>User</th>
                    <th>Quiz</th>
                    <th>Result Text</th>
                    <th>Timestamp</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($quiz_results as $result): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($result['id']); ?></td>
                        <td class="user"><?php echo htmlspecialchars($result['username']); ?></td>
                        <td class="quiz"><?php echo htmlspecialchars($result['quiz_name']); ?></td>
                        <td class="result-text"><?php echo htmlspecialchars($result['result']); ?></td>
                        <td class="timestamp"><?php echo htmlspecialchars($result['created_at']); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php elseif (!isset($page_error)): ?>
        <p>No quiz results found<?php echo $filter_active ? ' for the selected quiz' : ''; ?>.</p>
    <?php endif; ?>

    <p class="note">Displaying up to 100 most recent results.</p>

</body>
</html>
<?php
$conn->close(); // Close connection
?>
