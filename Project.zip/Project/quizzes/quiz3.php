<?php
session_start();
include '../db_connection.php';

$result = "";
$imagePath = ""; // Initialize image path variable
$primaryCategory = ""; // Initialize primary category

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // --- PHP code for processing the form ---
    $scores = [
        "SpongeBob" => 0,
        "Raven" => 0,
        "Jake" => 0,
        "Buttercup" => 0
    ];

    $questions = ['q1', 'q2', 'q3', 'q4'];
    $answeredAll = true; // Flag to check if all questions were answered

    // Check if all questions have been submitted
    foreach ($questions as $q) {
        if (!isset($_POST[$q])) {
            $answeredAll = false;
            break;
        }
    }

    // Proceed only if all questions were answered
    if ($answeredAll) {
        foreach ($questions as $q) {
            $choice = $_POST[$q];
            if (array_key_exists($choice, $scores)) {
                $scores[$choice]++;
            }
        }

        $maxScore = max($scores);
        $topCharacters = array_keys($scores, $maxScore);

        $descriptions = [
            "SpongeBob" => "You're SpongeBob! Full of energy, positivity, and chaotic good vibes.",
            "Raven" => "You're Raven. Quiet, smart, and surprisingly loyal underneath that sarcasm.",
            "Jake" => "You're Jake the Dog. Chill, wise, and always got a weirdly deep quote ready.",
            "Buttercup" => "You're Buttercup. Tough on the outside, but super loyal when it counts."
        ];

        if (count($topCharacters) > 1) {
            $result = "You're a mix of: " . implode(", ", $topCharacters);
            $primaryCategory = $topCharacters[0]; // Pick the first category for the image in case of a tie
        } else {
            $primaryCategory = $topCharacters[0];
            $result = $descriptions[$primaryCategory];
        }

        // --- Construct Image Path ---
        // Ensure primaryCategory is determined before trying to find an image
        if (!empty($primaryCategory)) {

            // *** NEW: Explicit mapping from category to image filename ***
            $imageMap = [
                "SpongeBob" => 'Spongebob.jpg', // Specific name from previous code
                "Raven"     => 'Raven.webp',
                "Jake"      => 'Jake.webp',
                "Buttercup" => 'Buttercup.webp'
                // Add more mappings here if needed in the future
            ];

            // Get the image filename from the map based on the result category
            // Use ?? '' to default to an empty string if the category isn't in the map
            $imageName = $imageMap[$primaryCategory] ?? '';

            // Proceed only if we found a corresponding image name in our map
            if (!empty($imageName)) {
                $potentialImagePath = '../images/' . $imageName;

                // Check if the actual file exists on the server
                $serverPath = $_SERVER['DOCUMENT_ROOT'] . '/Project/images/' . $imageName;
                if (file_exists($serverPath)) {
                    $imagePath = $potentialImagePath; // Use the relative web path for the <img> tag
                } else {
                    // Image file is missing on the server
                    $imagePath = ""; // Don't set a path, so the <img> tag won't render
                    error_log("Missing image file: " . $serverPath); // Log error for debugging
                }
            } else {
                 // The category determined wasn't found in our $imageMap
                 $imagePath = "";
                 error_log("No image mapped for category: " . $primaryCategory);
            }
        }
        // --- End Image Path Construction ---


        // Save answer if user is logged in
        if (isset($_SESSION['user_id'])) {
            $user_id = $_SESSION['user_id'];
            $quiz_id = 3;
            if (!empty($result)) {
                 $stmt = $conn->prepare("INSERT INTO quiz_answers (user_id, quiz_id, result) VALUES (?, ?, ?)");
                 if ($stmt) {
                     $stmt->bind_param("iis", $user_id, $quiz_id, $result);
                     $stmt->execute();
                     $stmt->close();
                 } else {
                     error_log("Failed to prepare statement: " . $conn->error);
                 }
            }
        }
    } else {
        $result = "Please answer all questions.";
    }
    // --- End of PHP processing ---
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Which Cartoon Character Are You?</title>
    <style>
        /* Optional: Add some basic styling */
        body { font-family: sans-serif; line-height: 1.6; padding: 20px; }
        h2, h3 { text-align: center; }
        form { max-width: 600px; margin: 20px auto; padding: 20px; border: 1px solid #ccc; border-radius: 8px; }
        form p { font-weight: bold; }
        label { display: block; margin-bottom: 8px; cursor: pointer; }
        button { display: block; margin: 20px auto; padding: 10px 25px; font-size: 16px; cursor: pointer; }
        .result-container { text-align: center; margin-top: 30px; }
        .result-container img { border: 1px solid #eee; padding: 5px; margin-top: 15px; max-width: 90%; height: auto; max-height: 300px; /* Optional max height */ }
        .nav-links { text-align: center; margin-top: 20px; }
        .nav-links a { margin: 0 10px; }
        .login-info { text-align: right; font-size: 0.9em; color: #555; }
    </style>
</head>
<body>

<div class="login-info">
<?php if (isset($_SESSION['user_id'])): ?>
    <p>Welcome back!</p>
<?php else: ?>
    <p>You're taking the quiz as a guest. <a href="../login/login.php">Log in</a> to save your results.</p>
<?php endif; ?>
</div>

<h2>Which Cartoon Character Are You?</h2>

<?php if ($_SERVER['REQUEST_METHOD'] == 'POST' && !empty($result) && $answeredAll): ?>
    <div class="result-container">
        <h3>Your Result:</h3>
        <p><?php echo htmlspecialchars($result); ?></p>

        <!-- Display the image if a valid path was found -->
        <?php if (!empty($imagePath)): ?>
            <img src="<?php echo htmlspecialchars($imagePath); ?>" alt="<?php echo htmlspecialchars($primaryCategory); ?> Result">
            <br>
        <?php elseif(!empty($primaryCategory)): ?>
             <!-- Optional: Show message if image file was missing or not mapped -->
             <p><small>(Image for <?php echo htmlspecialchars($primaryCategory); ?> not found)</small></p>
        <?php endif; ?>
        <!-- End image -->
    </div>
    <div class="nav-links">
        <a href="quiz3.php">Take it again</a>
        <a href="../index.php">Go back to the main menu</a>
    </div>
<?php elseif ($_SERVER['REQUEST_METHOD'] == 'POST' && !$answeredAll): ?>
     <div class="result-container">
        <p style="color: red;"><?php echo htmlspecialchars($result); ?></p> <!-- Show error if not all answered -->
        <a href="quiz3.php">Try again</a>
     </div>
<?php else: ?>
    <!-- The form remains the same -->
    <form method="POST" action="quiz3.php" id="quiz-form">
        <p>1. What's your approach to a problem?</p>
        <label><input type="radio" name="q1" value="SpongeBob" required> Jump in and figure it out on the way</label><br>
        <label><input type="radio" name="q1" value="Raven"> Analyze quietly and keep to yourself</label><br>
        <label><input type="radio" name="q1" value="Jake"> Go with the flow and see what happens</label><br>
        <label><input type="radio" name="q1" value="Buttercup"> Tackle it head-on and don’t back down</label><br>

        <p>2. What’s your ideal weekend?</p>
        <label><input type="radio" name="q2" value="SpongeBob" required> Making fun plans with friends</label><br>
        <label><input type="radio" name="q2" value="Raven"> Reading or chilling alone</label><br>
        <label><input type="radio" name="q2" value="Jake"> Napping, snacks, and music</label><br>
        <label><input type="radio" name="q2" value="Buttercup"> Doing something active or challenging</label><br>

        <p>3. Pick a snack:</p>
        <label><input type="radio" name="q3" value="SpongeBob" required> Burger and fries</label><br>
        <label><input type="radio" name="q3" value="Raven"> Herbal tea and dark chocolate</label><br>
        <label><input type="radio" name="q3" value="Jake"> Bacon pancakes</label><br>
        <label><input type="radio" name="q3" value="Buttercup"> Hot wings and a soda</label><br>

        <p>4. Your friend group would describe you as:</p>
        <label><input type="radio" name="q4" value="SpongeBob" required> Always cheerful and down for anything</label><br>
        <label><input type="radio" name="q4" value="Raven"> Mysterious but loyal</label><br>
        <label><input type="radio" name="q4" value="Jake"> Funny and unexpectedly wise</label><br>
        <label><input type="radio" name="q4" value="Buttercup"> Tough but secretly a softie</label><br>

        <button type="submit">Submit</button>
    </form>
<?php endif; ?>

<script src="quiz3.js"></script>

</body>
</html>
