<?php
session_start();
include '../db_connection.php';

$result = "";
$imagePath = ""; // Initialize image path variable
$primaryCategory = ""; // Initialize primary category
$answeredAll = true; // Flag to check if all questions were answered

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // --- PHP code for processing the form ---
    $scores = [
        "Summer" => 0,
        "Fall" => 0,
        "Spring" => 0,
        "Winter" => 0
    ];

    $questions = ['q1', 'q2', 'q3', 'q4'];

    // Check if all questions have been submitted
    foreach ($questions as $q) {
        if (!isset($_POST[$q])) {
            $answeredAll = false;
            break;
        }
    }

    // Proceed only if all questions were answered
    if ($answeredAll) {
        foreach ($questions as $q) {
            // We already know $_POST[$q] is set from the check above
            $choice = $_POST[$q];
            if (array_key_exists($choice, $scores)) {
                $scores[$choice]++;
            }
        }

        $maxScore = max($scores);
        $topCategories = array_keys($scores, $maxScore);

        $descriptions = [
            "Summer" => "You're Summer! Bright, energetic, and fun-loving.",
            "Fall" => "You're Fall! Thoughtful, calm, and cozy.",
            "Spring" => "You're Spring! Cheerful, fresh, and full of life.",
            "Winter" => "You're Winter! Quiet, cool, and elegant."
        ];

        if (count($topCategories) > 1) {
            $result = "You share qualities with multiple seasons: " . implode(", ", $topCategories);
            $primaryCategory = $topCategories[0]; // Pick the first category for the image in case of a tie
        } else {
            $primaryCategory = $topCategories[0];
            $result = $descriptions[$primaryCategory];
        }

        // --- Construct Image Path using explicit map ---
        if (!empty($primaryCategory)) {
             $imageMap = [
                 "Summer" => 'summer.jpg',
                 "Fall"   => 'fall.jpg',
                 "Spring" => 'spring.jpg',
                 "Winter" => 'winter.jpg'
             ];
             $imageName = $imageMap[$primaryCategory] ?? ''; // Find image name in map

             if (!empty($imageName)) {
                 $potentialImagePath = '../images/' . $imageName;
                 $serverPath = $_SERVER['DOCUMENT_ROOT'] . '/Project/images/' . $imageName;
                 if (file_exists($serverPath)) {
                     $imagePath = $potentialImagePath; // Set web path if file exists
                 } else {
                     $imagePath = ""; // Clear path if file missing
                     error_log("Missing image file for quiz2.php: " . $serverPath);
                 }
             } else {
                  $imagePath = ""; // Clear path if category not in map
                  error_log("No image mapped for category in quiz2.php: " . $primaryCategory);
             }
         }
        // --- End Image Path Construction ---


        // Save answer if user is logged in
        if (isset($_SESSION['user_id'])) {
            $user_id = $_SESSION['user_id'];
            $quiz_id = 2; // Quiz ID for this quiz
            if (!empty($result)) {
                 $stmt = $conn->prepare("INSERT INTO quiz_answers (user_id, quiz_id, result) VALUES (?, ?, ?)");
                 if ($stmt) { // Check prepare success
                     $stmt->bind_param("iis", $user_id, $quiz_id, $result);
                     $stmt->execute();
                     $stmt->close();
                 } else {
                     error_log("Failed to prepare statement for quiz2.php: " . $conn->error);
                 }
            }
        }
    } else { // Handle case where not all questions were answered
        $result = "Please answer all questions.";
    }
    // --- End of PHP processing ---
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>What Season Are You?</title>
    <!-- Styling (same as quiz3.php) -->
    <style>
        body { font-family: sans-serif; line-height: 1.6; padding: 20px; }
        h2, h3 { text-align: center; }
        form { max-width: 600px; margin: 20px auto; padding: 20px; border: 1px solid #ccc; border-radius: 8px; }
        form p { font-weight: bold; }
        label { display: block; margin-bottom: 8px; cursor: pointer; }
        button { display: block; margin: 20px auto; padding: 10px 25px; font-size: 16px; cursor: pointer; }
        .result-container { text-align: center; margin-top: 30px; }
        .result-container img { border: 1px solid #eee; padding: 5px; margin-top: 15px; max-width: 90%; height: auto; max-height: 300px; /* Optional max height */ }
        .nav-links { text-align: center; margin-top: 20px; }
        .nav-links a { margin: 0 10px; }
        .login-info { text-align: right; font-size: 0.9em; color: #555; }
    </style>
</head>
<body>

<div class="login-info">
<?php if (isset($_SESSION['user_id'])): ?>
    <p>Welcome back!</p>
<?php else: ?>
    <p>You're taking the quiz as a guest. <a href="../login/login.php">Log in</a> to save your results.</p>
<?php endif; ?>
</div>

<h2>What Season Are You?</h2>

<!-- Updated Result Display Section -->
<?php if ($_SERVER['REQUEST_METHOD'] == 'POST' && !empty($result) && $answeredAll): ?>
    <div class="result-container"> <!-- Added result container div -->
        <h3>Your Result:</h3>
        <p><?php echo htmlspecialchars($result); ?></p>

        <!-- Display the image if a valid path was found -->
        <?php if (!empty($imagePath)): ?>
            <img src="<?php echo htmlspecialchars($imagePath); ?>" alt="<?php echo htmlspecialchars($primaryCategory); ?> Result"> <!-- Removed inline style -->
            <br>
        <?php elseif(!empty($primaryCategory)): ?>
             <!-- Optional: Show message if image file was missing or not mapped -->
             <p><small>(Image for <?php echo htmlspecialchars($primaryCategory); ?> not found)</small></p>
        <?php endif; ?>
        <!-- End image -->
    </div>
    <div class="nav-links"> <!-- Added nav links div -->
        <a href="quiz2.php">Take it again</a>
        <a href="../index.php">Go back to the main menu</a>
    </div>
<?php elseif ($_SERVER['REQUEST_METHOD'] == 'POST' && !$answeredAll): ?> <!-- Handle incomplete submission -->
     <div class="result-container"> <!-- Use container for error message -->
        <p style="color: red;"><?php echo htmlspecialchars($result); ?></p> <!-- Show error -->
        <a href="quiz2.php">Try again</a>
     </div>
<?php else: ?>
    <!-- The form (remains the same) -->
    <form method="POST" action="quiz2.php" id="quiz-form">
        <p>1. What’s your favorite kind of weather?</p>
        <label><input type="radio" name="q1" value="Summer" required> Hot and sunny</label><br>
        <label><input type="radio" name="q1" value="Fall"> Crisp and cool</label><br>
        <label><input type="radio" name="q1" value="Spring"> Mild and breezy</label><br>
        <label><input type="radio" name="q1" value="Winter"> Cold and snowy</label><br>

        <p>2. Pick a drink:</p>
        <label><input type="radio" name="q2" value="Summer" required> Lemonade</label><br>
        <label><input type="radio" name="q2" value="Fall"> Pumpkin Spice Latte</label><br>
        <label><input type="radio" name="q2" value="Spring"> Iced Tea</label><br>
        <label><input type="radio" name="q2" value="Winter"> Hot Chocolate</label><br>

        <p>3. What kind of vacation sounds best?</p>
        <label><input type="radio" name="q3" value="Summer" required> Beach trip</label><br>
        <label><input type="radio" name="q3" value="Fall"> Mountain cabin</label><br>
        <label><input type="radio" name="q3" value="Spring"> Flower garden tour</label><br>
        <label><input type="radio" name="q3" value="Winter"> Ski resort</label><br>

        <p>4. What's your favorite holiday?</p>
        <label><input type="radio" name="q4" value="Summer" required> 4th of July</label><br>
        <label><input type="radio" name="q4" value="Fall"> Thanksgiving</label><br>
        <label><input type="radio" name="q4" value="Spring"> Easter</label><br>
        <label><input type="radio" name="q4" value="Winter"> Christmas</label><br>

        <button type="submit">Submit</button>
    </form>
<?php endif; ?>
<!-- End Updated Result Display Section -->

<script src="quiz2.js"></script>

</body>
</html>
