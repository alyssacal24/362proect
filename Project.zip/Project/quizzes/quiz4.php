<?php
session_start();
include '../db_connection.php';

$result = "";
$imagePath = ""; // Initialize image path variable
$primaryCategory = ""; // Initialize primary category
$answeredAll = true; // Flag to check if all questions were answered

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // --- PHP code for processing the form ---
    // Quiz 4 specific scores
    $scores = [
        "Apple Juice" => 0,
        "Grape Juice" => 0,
        "Orange-Mango Fusion" => 0,
        "Kelp Shake" => 0 // Using a shorter key for simplicity
    ];

    $questions = ['q1', 'q2', 'q3', 'q4'];

    // Check if all questions have been submitted (Server-side validation)
    foreach ($questions as $q) {
        if (!isset($_POST[$q])) {
            $answeredAll = false;
            break;
        }
    }

    // Proceed only if all questions were answered
    if ($answeredAll) {
        foreach ($questions as $q) {
            $choice = $_POST[$q];
            if (array_key_exists($choice, $scores)) {
                $scores[$choice]++;
            }
        }

        $maxScore = max($scores);
        $topCategories = array_keys($scores, $maxScore);

        // Quiz 4 specific descriptions
        $descriptions = [
            "Apple Juice" => "You’re classic, dependable, and lowkey comforting. People trust you with their secrets, and you always have tissues. Spiritually? You’re a well-organized Google Drive folder.",
            "Grape Juice" => "You’re a little weird, kind of chaotic, and absolutely unforgettable. The vibes are immaculate, even if nobody knows why. Spiritually? You once accidentally started a group chat war.",
            "Orange-Mango Fusion" => "You bring drama in the best way. High energy, spontaneous, and probably convinced everyone to do karaoke at 2AM. Spiritually? You’re the personification of ✨main character energy✨.",
            "Kelp Shake" => "You’re strange. No one really knows what flavor you are, but they keep drinking. You give off ambiguous meme energy, talk in SpongeBob references, and somehow thrive in the chaos. Spiritually? You live in Bikini Bottom but only shop at Hot Topic."
        ];

        if (count($topCategories) > 1) {
            $result = "You're a mix of energies: " . implode(", ", $topCategories);
            $primaryCategory = $topCategories[0]; // Pick the first category for the image in case of a tie
        } else {
            $primaryCategory = $topCategories[0];
            $result = $descriptions[$primaryCategory];
        }

        // --- Construct Image Path using explicit map ---
        if (!empty($primaryCategory)) {
             // Quiz 4 specific image map
             $imageMap = [
                 "Apple Juice"          => 'apple.avif',
                 "Grape Juice"          => 'grape.jpg',
                 "Orange-Mango Fusion"  => 'orangemango.png',
                 "Kelp Shake" => 'kelpshake.webp'
             ];
             $imageName = $imageMap[$primaryCategory] ?? ''; // Find image name in map

             if (!empty($imageName)) {
                 $potentialImagePath = '../images/' . $imageName;
                 $serverPath = $_SERVER['DOCUMENT_ROOT'] . '/Project/images/' . $imageName;
                 if (file_exists($serverPath)) {
                     $imagePath = $potentialImagePath; // Set web path if file exists
                 } else {
                     $imagePath = ""; // Clear path if file missing
                     error_log("Missing image file for quiz4.php: " . $serverPath);
                 }
             } else {
                  $imagePath = ""; // Clear path if category not in map
                  error_log("No image mapped for category in quiz4.php: " . $primaryCategory);
             }
         }
        // --- End Image Path Construction ---


        // Save answer if user is logged in
        if (isset($_SESSION['user_id'])) {
            $user_id = $_SESSION['user_id'];
            $quiz_id = 4; // <<<--- IMPORTANT: Set Quiz ID to 4
            if (!empty($result)) {
                 $stmt = $conn->prepare("INSERT INTO quiz_answers (user_id, quiz_id, result) VALUES (?, ?, ?)");
                 if ($stmt) { // Check prepare success
                     $stmt->bind_param("iis", $user_id, $quiz_id, $result);
                     $stmt->execute();
                     $stmt->close();
                 } else {
                     error_log("Failed to prepare statement for quiz4.php: " . $conn->error);
                 }
            }
        }
    } else { // Handle case where not all questions were answered
        $result = "Please answer all questions.";
    }
    // --- End of PHP processing ---
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>What Juice Box Are You Spiritually?</title> <!-- Quiz 4 Title -->
    <!-- Styling (consistent with others) -->
    <style>
        body { font-family: sans-serif; line-height: 1.6; padding: 20px; }
        h2, h3 { text-align: center; }
        form { max-width: 600px; margin: 20px auto; padding: 20px; border: 1px solid #ccc; border-radius: 8px; }
        form p { font-weight: bold; }
        label { display: block; margin-bottom: 8px; cursor: pointer; }
        button { display: block; margin: 20px auto; padding: 10px 25px; font-size: 16px; cursor: pointer; }
        .result-container { text-align: center; margin-top: 30px; }
        .result-container img { border: 1px solid #eee; padding: 5px; margin-top: 15px; max-width: 90%; height: auto; max-height: 300px; /* Optional max height */ }
        .nav-links { text-align: center; margin-top: 20px; }
        .nav-links a { margin: 0 10px; }
        .login-info { text-align: right; font-size: 0.9em; color: #555; }
    </style>
</head>
<body>

<div class="login-info">
<?php if (isset($_SESSION['user_id'])): ?>
    <p>Welcome back!</p>
<?php else: ?>
    <p>You're taking the quiz as a guest. <a href="../login/login.php">Log in</a> to save your results.</p>
<?php endif; ?>
</div>

<h2>What Juice Box Are You Spiritually?</h2> <!-- Quiz 4 Heading -->
<p style="text-align: center; font-style: italic; color: #666;">Because deep down, we all give Capri Sun energy sometimes.</p>


<!-- Result Display Section -->
<?php if ($_SERVER['REQUEST_METHOD'] == 'POST' && !empty($result) && $answeredAll): ?>
    <div class="result-container">
        <h3>Your Result:</h3>
        <p><?php echo htmlspecialchars($result); ?></p>

        <!-- Display the image if a valid path was found -->
        <?php if (!empty($imagePath)): ?>
            <img src="<?php echo htmlspecialchars($imagePath); ?>" alt="<?php echo htmlspecialchars($primaryCategory); ?> Result">
            <br>
        <?php elseif(!empty($primaryCategory)): ?>
             <p><small>(Image for <?php echo htmlspecialchars($primaryCategory); ?> not found)</small></p>
        <?php endif; ?>
    </div>
    <div class="nav-links">
        <a href="quiz4.php">Take it again</a> <!-- Link to self -->
        <a href="../index.php">Go back to the main menu</a>
    </div>
<?php elseif ($_SERVER['REQUEST_METHOD'] == 'POST' && !$answeredAll): ?>
     <div class="result-container">
        <p style="color: red;"><?php echo htmlspecialchars($result); ?></p> <!-- Show error -->
        <a href="quiz4.php">Try again</a> <!-- Link to self -->
     </div>
<?php else: ?>
    <!-- The form for Quiz 4 -->
    <form method="POST" action="quiz4.php" id="quiz-form"> <!-- Action points to self -->

        <p>1. It’s a random Tuesday. How are you feeling?</p>
        <label><input type="radio" name="q1" value="Apple Juice" required> A) Chill and go-with-the-flow </label><br>
        <label><input type="radio" name="q1" value="Grape Juice"> B) Lowkey chaotic but vibing </label><br>
        <label><input type="radio" name="q1" value="Orange-Mango Fusion"> C) Mysteriously energized with no explanation </label><br>
        <label><input type="radio" name="q1" value="Kelp Shake"> D) Fluctuating between 0 and 100 like it’s a sport</label><br>

        <p>2. What’s your preferred communication style?</p>
        <label><input type="radio" name="q2" value="Apple Juice" required> A) Thought-out texts with emojis</label><br>
        <label><input type="radio" name="q2" value="Grape Juice"> B) Voice messages full of side tangents</label><br>
        <label><input type="radio" name="q2" value="Orange-Mango Fusion"> C) Unhinged TikToks and reaction gifs</label><br>
        <label><input type="radio" name="q2" value="Kelp Shake"> D) Highly specific references that only 2 people understand</label><br>

        <p>3. You’re handed the aux cord. What do you play?</p>
        <label><input type="radio" name="q3" value="Apple Juice" required> A) Something everyone likes — chill pop or lo-fi</label><br>
        <label><input type="radio" name="q3" value="Grape Juice"> B) Your favorite banger, regardless of genre</label><br>
        <label><input type="radio" name="q3" value="Orange-Mango Fusion"> C) A playlist called “✨This Makes Sense Somehow✨”</label><br>
        <label><input type="radio" name="q3" value="Kelp Shake"> D) A chaotic mix with questionable transitions but immaculate vibes</label><br>

        <p>4. Pick a random item to spiritually attach yourself to:</p>
        <label><input type="radio" name="q4" value="Apple Juice" required> A) Cozy sweater</label><br>
        <label><input type="radio" name="q4" value="Grape Juice"> B) Rollerblades</label><br>
        <label><input type="radio" name="q4" value="Orange-Mango Fusion"> C) Shiny rock</label><br>
        <label><input type="radio" name="q4" value="Kelp Shake"> D) Seashells</label><br>

        <button type="submit">Submit</button>
    </form>
<?php endif; ?>
<!-- End Result Display Section -->

<script src="quiz4.js"></script> <!-- Link to correct JS file -->

</body>
</html>
