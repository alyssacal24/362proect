<?php
// File: quizzes/take_quiz.php

// --- ENABLE ERROR REPORTING FOR DEBUGGING ---
// --- REMOVE OR COMMENT THESE OUT FOR PRODUCTION ---
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
// ---------------------------------------------

session_start();
// Adjust the path according to the location of take_quiz.php
// This assumes db_connection.php is in the 'Project' folder, one level up.
require_once __DIR__ . '/../db_connection.php';

// Check if the database connection was successful (assuming $conn is created in db_connection.php)
if (!$conn) {
    die("Database connection failed. Please check db_connection.php and ensure MySQL is running.");
}
if ($conn->connect_error) {
    die("Database connection error: (" . $conn->connect_errno . ") " . $conn->connect_error);
}


// --- Get Quiz ID ---
if (!isset($_GET['id']) || !filter_var($_GET['id'], FILTER_VALIDATE_INT) || $_GET['id'] <= 0) {
    // Redirect to homepage or show a generic error if ID is invalid
    // Using die() for now to make errors obvious during debugging
    die("Invalid or missing Quiz ID provided in the URL.");
    // header('Location: ../index.php?error=invalid_quiz');
    // exit;
}
$quiz_id = (int)$_GET['id'];

// --- Fetch Quiz Details (Check if active) ---
$quiz_name = '';
// Ensure 'is_active' column exists in your 'quizzes' table
$stmt_quiz = $conn->prepare("SELECT name FROM quizzes WHERE id = ? AND is_active = 1");
if (!$stmt_quiz) { die("DB Prepare Error (Quiz Select): " . $conn->error); }
$stmt_quiz->bind_param("i", $quiz_id);
if (!$stmt_quiz->execute()) { die("DB Execute Error (Quiz Select): " . $stmt_quiz->error); }
$quizResult = $stmt_quiz->get_result();
if (!($quiz = $quizResult->fetch_assoc())) {
    // Quiz not found or not active
    die("Quiz with ID {$quiz_id} not found or is not active.");
    // header('Location: ../index.php?error=quiz_unavailable');
    // exit;
}
$quiz_name = $quiz['name'];
$stmt_quiz->close();

// --- Fetch Questions for this Quiz ---
$questions = []; // Stores question_id => question_text
$question_ids = []; // Stores just the IDs for fetching options
// Ensure 'question_order' column exists in your 'questions' table
$stmt_questions = $conn->prepare("SELECT id, question FROM questions WHERE quiz_id = ? ORDER BY question_order ASC, id ASC");
if (!$stmt_questions) { die("DB Prepare Error (Question Select): " . $conn->error); }
$stmt_questions->bind_param("i", $quiz_id);
if (!$stmt_questions->execute()) { die("DB Execute Error (Question Select): " . $stmt_questions->error); }
$questionsResult = $stmt_questions->get_result();
while ($row = $questionsResult->fetch_assoc()) {
    $questions[$row['id']] = $row['question'];
    $question_ids[] = $row['id'];
}
$stmt_questions->close();

if (empty($questions)) {
    // Quiz has no questions, redirect or show message
    die("This quiz (ID: {$quiz_id}) currently has no questions.");
    // header('Location: ../index.php?error=quiz_empty');
    // exit;
}

// --- Fetch Options for ALL questions in this quiz ---
$options = []; // Stores question_id => [array of options]
if (!empty($question_ids)) {
    $placeholders = implode(',', array_fill(0, count($question_ids), '?')); // ?,?,?
    $types = str_repeat('i', count($question_ids)); // i,i,i
    // Ensure 'personality_type' column exists in your 'options' table
    $sql_options = "SELECT id, question_id, option_text, personality_type FROM options WHERE question_id IN ($placeholders) ORDER BY question_id, id ASC"; // Add option_order later if needed

    $stmt_options = $conn->prepare($sql_options);
    // Check if prepare failed (e.g., syntax error, table/column doesn't exist)
    if (!$stmt_options) { die("DB Prepare Error (Option Select): " . $conn->error); }

    // Check if bind_param is needed and successful
    // Argument unpacking (...) requires PHP 5.6+
    if (!empty($types)) {
        if (!$stmt_options->bind_param($types, ...$question_ids)) { die("DB Bind Param Error (Option Select): " . $stmt_options->error); }
    }

    if (!$stmt_options->execute()) { die("DB Execute Error (Option Select): " . $stmt_options->error); }
    $optionsResult = $stmt_options->get_result();
    while ($row = $optionsResult->fetch_assoc()) {
        // Group options by question ID
        $options[$row['question_id']][] = $row;
    }
    $stmt_options->close();
}

// --- Fetch Result Definitions for this Quiz ---
$resultDefinitions = []; // Stores category_name => [description, image]
// Ensure 'result_definitions' table and columns exist
$stmt_defs = $conn->prepare("SELECT category_name, result_description, image_filename FROM result_definitions WHERE quiz_id = ?");
if (!$stmt_defs) { die("DB Prepare Error (Result Def Select): " . $conn->error); }
$stmt_defs->bind_param("i", $quiz_id);
if (!$stmt_defs->execute()) { die("DB Execute Error (Result Def Select): " . $stmt_defs->error); }
$resultDefsResult = $stmt_defs->get_result();
while ($row = $resultDefsResult->fetch_assoc()) {
    $resultDefinitions[$row['category_name']] = [
        'description' => $row['result_description'],
        'image' => $row['image_filename']
    ];
}
$stmt_defs->close();

// --- Initialize variables for result display ---
$result_text = "";
$result_image_path = "";
$result_category_name = "";
$show_result = false;
$error_message = "";


// --- Process Form Submission ---
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $scores = [];
    // Initialize scores based on fetched definitions
    foreach ($resultDefinitions as $category => $def) {
        $scores[$category] = 0;
    }

    $answered_all = true;
    // Check if all questions were answered
    foreach ($question_ids as $q_id) {
        if (!isset($_POST['q_' . $q_id])) {
            $answered_all = false;
            $error_message = "Please answer all questions.";
            break;
        }
    }

    if ($answered_all) {
        // Calculate scores
        foreach ($question_ids as $q_id) {
            $chosen_category = $_POST['q_' . $q_id];
            // Ensure the chosen category is valid for this quiz
            if (array_key_exists($chosen_category, $scores)) {
                $scores[$chosen_category]++;
            } else {
                // This shouldn't happen if form values are correct, but good to check
                error_log("Invalid category '{$chosen_category}' submitted for quiz {$quiz_id}, question {$q_id}");
                $answered_all = false; // Treat as invalid submission
                $error_message = "An error occurred processing your answers. Please try again.";
                break;
            }
        }

        if ($answered_all) { // Re-check in case of invalid category
            // Determine result
            $maxScore = 0;
            if (!empty($scores)) {
                $maxScore = max($scores);
            } else {
                 // This might happen if $resultDefinitions was empty
                 $error_message = "Cannot calculate result: No result definitions found for this quiz.";
                 $answered_all = false; // Prevent further processing
            }


            if ($answered_all && $maxScore > 0) { // Proceed only if no errors and score > 0
                $topCategories = array_keys($scores, $maxScore);

                if (count($topCategories) > 1) {
                    // Tie-breaker: Simple approach - pick the first one, maybe generate generic text
                    $result_category_name = $topCategories[0]; // Or handle tie differently
                    // You could create a more generic tie message here if desired
                    $result_text = $resultDefinitions[$result_category_name]['description'] ?? "Result description not found."; // Default to first tied category's text
                    // $result_text = "You have traits from multiple types: " . implode(", ", $topCategories); // Alternative tie message

                } else {
                    // Single winner
                    $result_category_name = $topCategories[0];
                    $result_text = $resultDefinitions[$result_category_name]['description'] ?? "Result description not found.";
                }

                // Get Image Path
                $imageName = $resultDefinitions[$result_category_name]['image'] ?? null;
                if (!empty($imageName)) {
                    // Construct path relative to the web root for the <img> tag
                    $potentialImagePathWeb = '../images/' . $imageName;
                    // Construct server path to check file existence
                    // Make sure '/Project/' matches your setup if it's not directly under htdocs
                    $docRoot = rtrim($_SERVER['DOCUMENT_ROOT'], '/'); // Remove trailing slash if present
                    $projectPath = '/Project'; // Adjust if your project folder has a different name or path
                    $potentialImagePathServer = $docRoot . $projectPath . '/images/' . $imageName;

                    if (file_exists($potentialImagePathServer)) {
                        $result_image_path = $potentialImagePathWeb;
                    } else {
                        error_log("Missing image file for dynamic quiz result: " . $potentialImagePathServer);
                        // Image path remains empty, won't show broken image
                    }
                }
                $show_result = true; // Flag to display result section

            } elseif ($answered_all) { // If answered all but maxScore is 0
                $error_message = "Could not determine a result based on your answers.";
            }

            // Save answer if user logged in AND result was determined
            if ($show_result && isset($_SESSION['user_id'])) {
                $user_id = $_SESSION['user_id'];
                // Ensure 'quiz_answers' table and columns exist
                $stmt_save = $conn->prepare("INSERT INTO quiz_answers (user_id, quiz_id, result) VALUES (?, ?, ?)");
                if ($stmt_save) {
                    $stmt_save->bind_param("iis", $user_id, $quiz_id, $result_text);
                    if (!$stmt_save->execute()) {
                         error_log("Failed to execute save answer: " . $stmt_save->error);
                         // Don't necessarily show DB error to user, maybe generic message
                    }
                    $stmt_save->close();
                } else {
                    error_log("Failed to prepare statement for saving answer: " . $conn->error);
                }
            }
        } // end if ($answered_all) re-check
    } // end if ($answered_all) initial check
} // End POST processing

?>
<!DOCTYPE html>
<html>
<head>
    <title><?php echo htmlspecialchars($quiz_name); ?></title>
    <link rel="stylesheet" href="../style.css"> <!-- Adjust path if needed -->
     <style> /* Basic styling for demonstration */
        body { font-family: sans-serif; line-height: 1.6; padding: 20px; max-width: 800px; margin: 0 auto; }
        h2, h3 { text-align: center; color: #333; }
        form { margin: 20px auto; padding: 20px; border: 1px solid #ccc; border-radius: 8px; background-color: #f9f9f9;}
        .question-block { margin-bottom: 25px; padding-bottom: 15px; border-bottom: 1px dashed #eee; }
        .question-block p { font-weight: bold; margin-bottom: 10px; color: #555;}
        label { display: block; margin-bottom: 8px; cursor: pointer; padding: 5px; border-radius: 4px; transition: background-color 0.2s; }
        label:hover { background-color: #e9e9e9; }
        input[type="radio"] { margin-right: 8px; }
        button[type="submit"] { display: block; margin: 20px auto; padding: 12px 30px; font-size: 16px; cursor: pointer; background-color: #5cb85c; color: white; border: none; border-radius: 5px; transition: background-color 0.2s;}
        button[type="submit"]:hover { background-color: #4cae4c; }
        .result-container { text-align: center; margin-top: 30px; padding: 20px; border: 1px solid #ddd; border-radius: 8px; background-color: #f0f8ff; }
        .result-container img { border: 1px solid #eee; padding: 5px; margin-top: 15px; max-width: 90%; height: auto; max-height: 350px; border-radius: 4px; }
        .nav-links { text-align: center; margin-top: 20px; }
        .nav-links a { margin: 0 15px; text-decoration: none; color: #337ab7; }
        .login-info { text-align: right; font-size: 0.9em; color: #555; margin-bottom: 15px; }
        .error { color: #a94442; background-color: #f2dede; border: 1px solid #ebccd1; padding: 10px; border-radius: 4px; text-align: center; font-weight: bold; margin: 15px 0;}
    </style>
</head>
<body>

<div class="login-info">
    <?php if (isset($_SESSION['user_id'])): ?>
        <span>Welcome back, <?php echo htmlspecialchars($_SESSION['username']); ?>! | <a href="../login/logout.php">Logout</a></span>
    <?php else: ?>
        <span>Taking quiz as guest. <a href="../login/login.php">Log in</a> or <a href="../login/register.php">Register</a> to save results.</span>
    <?php endif; ?>
</div>

<h2><?php echo htmlspecialchars($quiz_name); ?></h2>

<?php if (!empty($error_message)): ?>
    <p class="error"><?php echo htmlspecialchars($error_message); ?></p>
<?php endif; ?>


<?php if ($show_result): ?>
    <!-- Display Result -->
    <div class="result-container">
        <h3>Your Result:</h3>
        <p><?php echo nl2br(htmlspecialchars($result_text)); // Use nl2br if descriptions might have newlines ?></p>
        <?php if (!empty($result_image_path)): ?>
            <img src="<?php echo htmlspecialchars($result_image_path); ?>" alt="<?php echo htmlspecialchars($result_category_name); ?> Result">
        <?php elseif(!empty($result_category_name)): ?>
             <p><small>(Image for <?php echo htmlspecialchars($result_category_name); ?> not found)</small></p>
        <?php endif; ?>
    </div>
    <div class="nav-links">
        <a href="take_quiz.php?id=<?php echo $quiz_id; ?>">Take it again</a>
        <a href="../index.php">Back to Main Menu</a>
    </div>

<?php elseif (!$show_result): // Show form if it's GET or if POST had an error (error message displayed above) ?>
    <!-- Display Quiz Form -->
    <form method="POST" action="take_quiz.php?id=<?php echo $quiz_id; ?>" id="quiz-form">
        <?php
            $can_submit = true; // Flag to check if all questions have options
            foreach ($questions as $q_id => $q_text):
        ?>
            <div class="question-block">
                <p><?php echo htmlspecialchars($q_text); ?></p>
                <?php if (isset($options[$q_id]) && !empty($options[$q_id])): ?>
                    <?php foreach ($options[$q_id] as $option): ?>
                        <label>
                            <input type="radio" name="q_<?php echo $q_id; ?>" value="<?php echo htmlspecialchars($option['personality_type']); ?>" required>
                            <?php echo htmlspecialchars($option['option_text']); ?>
                        </label>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p style="color: red;"><em>Error: No options found for this question. Please contact an administrator.</em></p>
                    <?php $can_submit = false; // Prevent submission if a question has no options ?>
                <?php endif; ?>
            </div> <!-- /question-block -->
        <?php endforeach; ?>

        <?php if ($can_submit): // Only show submit button if all questions had options ?>
             <button type="submit">See My Result!</button>
        <?php else: ?>
             <p class="error">Cannot submit quiz because one or more questions are missing options.</p>
        <?php endif; ?>
    </form>
<?php endif; ?>

</body>
</html>
<?php
if (isset($conn)) { // Close connection if it was successfully created
    $conn->close();
}
?>
